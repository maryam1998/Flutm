import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import '../models/constants.dart';
import '../models/jalali.dart';
import '../models/map_models.dart';
import '../state/goal_ops.dart';
import '../theme/app_theme.dart' show kLightInk;
import 'camera.dart';
import 'draw_utils.dart';
import 'geometry.dart' as geo;
import 'hit_registry.dart';
import 'map_ops.dart';
import 'user_state.dart';

const kLabelRtlAnchor = false;

double _l(double a, double b, double t) => a + (b - a) * t;

/// ease in-out (کند → تند → کند)
double _easeInOut(double t) {
  if (t < 0.5) return 2 * t * t;
  final u = -2 * t + 2;
  return 1 - u * u / 2;
}

class MapPainter extends CustomPainter {
  MapPainter({
    required this.state,
    required this.cam,
    required this.time,
    required this.images,
    required this.boundsBox,
    required this.hits,
    this.isDark = true,
  }) : super(repaint: Listenable.merge([cam, time, images]));

  final MapState state;
  final CameraController cam;
  final ValueNotifier<double> time;
  final NodeImageCache images;
  final MapBoundsBox boundsBox;
  final HitRegistry hits;
  final bool isDark;
  final List<Offset> _pts = [];

  double get _t => time.value;

  @override
  bool shouldRepaint(covariant MapPainter old) => true;

  // ───────────────────────── رنگ و اندازه ─────────────────────────

  Color get _textColor {
    final c = state.textColor.toLowerCase().trim();
    final auto = isDark ? Colors.white : kLightInk;
    if (c == '#000000' || c == '#000') return Colors.black;
    if (c.isEmpty || c == '#eef0fa' || c == '#ffffff' || c == '#fff') {
      return auto;
    }
    return hexColor(c, auto);
  }

  double _fs() => math.max(14, state.fontSize);
  double _labelSize(String type, [double scale = 1]) {
    switch (type) {
      case 'me':
        return _fs() + 3;
      case 'goal':
        return _fs();
      case 'ring':
        return _fs() - 2;
      default:
        return math.max(12, state.fontSize * math.min(1.0, scale + 0.3));
    }
  }

  String _formatStamp(int ts) {
    try {
      final d = DateTime.fromMillisecondsSinceEpoch(ts);
      final parts = <String>[];
      if (state.showDateStamps) {
        final j = toJalaali(d.year, d.month, d.day);
        parts.add('${toFa(j.jy)}/${toFa(j.jm)}/${toFa(j.jd)}');
      }
      if (state.showTimeStamps) {
        parts.add(
            '${toFa(d.hour.toString().padLeft(2, '0'))}:${toFa(d.minute.toString().padLeft(2, '0'))}');
      }
      return parts.join(' — ');
    } catch (_) {
      return '';
    }
  }

  void _ringLink(Canvas canvas, Goal g, Ring r) {
    final dx = r.x - g.x;
    final dy = r.y - g.y;
    final d = math.sqrt(dx * dx + dy * dy);
    if (d < 1) return;
    final ux = dx / d;
    final uy = dy / d;
    final x1 = g.x + ux * (g.radius + 6);
    final y1 = g.y + uy * (g.radius + 6);
    final x2 = r.x - ux * (r.radius + 6);
    final y2 = r.y - uy * (r.radius + 6);
    final mx = (x1 + x2) / 2 - uy * d * 0.12;
    final my = (y1 + y2) / 2 + ux * d * 0.12;

    final col = hexColor(r.color, hexColor(kRingColor));
    final path = Path()
      ..moveTo(x1, y1)
      ..quadraticBezierTo(mx, my, x2, y2);

    drawDashed(
      canvas,
      path,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..strokeCap = StrokeCap.round
        ..color = withOp(col, 0.6),
      const [2, 7],
    );
  }

  // ───────────────────────── paint ─────────────────────────

  @override
  void paint(Canvas canvas, Size size) {
    textCache.setOutline(
        isDark ? const Color(0xFF0A0C18) : const Color(0xFFF5EFE0));
    _pts.clear();
    hits.clear();
    canvas.save();
    canvas.translate(cam.x, cam.y);
    canvas.scale(cam.scale);
    final tc = _textColor;

    for (final g in state.goals) {
      _branches(canvas, g, tc, trunkOnly: g.collapsed && g.actions.isNotEmpty);
    }
    if (!state.ringsCollapsed) {
      for (final r in state.rings) {
        if (r.actions.isNotEmpty) {
          final lg = _goalOf(r);
          _branches(canvas, r, tc,
              trunkOnly: r.collapsed || (lg?.collapsed ?? false));
        }
      }
    }
    if (state.showRingLinks && !state.ringsCollapsed) {
      for (final r in state.rings) {
        if (r.goalId.isEmpty) continue;
        Goal? lg;
        for (final gg in state.goals) {
          if (gg.id == r.goalId) {
            lg = gg;
            break;
          }
        }
        if (lg == null) continue;
        _ringLink(canvas, lg, r);
      }
    }
    _drawMe(canvas, tc);
    for (final g in state.goals) {
      _drawGoal(canvas, g, tc);
    }
    if (!state.ringsCollapsed) {
      for (final r in state.rings) {
        _drawRing(canvas, r, tc);
      }
    }
    canvas.restore();

    if (_pts.isNotEmpty) {
      var minX = _pts.first.dx, maxX = minX, minY = _pts.first.dy, maxY = minY;
      for (final p in _pts) {
        minX = math.min(minX, p.dx);
        maxX = math.max(maxX, p.dx);
        minY = math.min(minY, p.dy);
        maxY = math.max(maxY, p.dy);
      }
      boundsBox.rect = Rect.fromLTRB(minX, minY, maxX, maxY).inflate(30);
    }
  }

  Goal? _goalOf(Ring r) {
    for (final g in state.goals) {
      if (g.id == r.goalId) return g;
    }
    return null;
  }

  void _addCircleBounds(Offset c, double r) {
    _pts..add(c.translate(-r, -r))..add(c.translate(r, r));
  }

  // ───────────────────────── هاله ─────────────────────────

  void _halo(Canvas canvas, Offset c, Color color, double r, double pf,
      String? freqKey) {
    final f = kFreqBands[freqKey] ?? kFreqBands['alpha']!;
    final base = f.speed;
    double tri(double dur) {
      final p = (_t / dur) % 1.0;
      return p < 0.5 ? p * 2 : (1 - p) * 2;
    }

    final blur =
        cam.scale < 0.3 ? null : const MaskFilter.blur(BlurStyle.normal, 4);
    final to = tri(base * 1.35);
    canvas.drawCircle(c, _l(r * 1.7 * pf, r * 2.2 * pf, to),
        Paint()
          ..color = withOp(color, _l(0.07, 0.16, to))
          ..maskFilter = blur);
    final tm = tri(base);
    canvas.drawCircle(c, _l(r * 1.25 * pf, r * 1.55 * pf, tm),
        Paint()
          ..color = withOp(color, _l(0.13, 0.24, tm))
          ..maskFilter = blur);
    final ti = tri(base * 0.8);
    canvas.drawCircle(
        c,
        _l(r * 0.88 * pf, r * 1.08 * pf, ti),
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.4
          ..color = withOp(color, _l(0.45, 0.75, ti)));
  }

  void _aura(Canvas canvas, Offset c, double r, UserFreq u) {
    final band = kFreqBands[u.band]!;
    final col = hexColor(band.color);
    final glowR = r * (1.6 + u.progress * 0.9);
    final glowOp = 0.15 + u.progress * 0.25;
    canvas.drawCircle(c, glowR, Paint()..color = withOp(col, glowOp));
    canvas.drawCircle(c, glowR * 0.6,
        Paint()..color = withOp(Colors.white, glowOp * 0.55));
    final dur = band.speed * 1.4;
    final op = 0.35 + u.progress * 0.45;
    for (var i = 0; i < 3; i++) {
      final local = _t - i * band.speed / 3;
      if (local < 0) continue;
      final p = (local % dur) / dur;
      canvas.drawCircle(
          c,
          _l(r * 1.15, r * 3.2, p),
          Paint()
            ..style = PaintingStyle.stroke
            ..strokeWidth = 1.4 + u.progress * 1.6
            ..color = withOp(col, op * (1 - p)));
    }
  }

  void _circleImage(Canvas canvas, Offset c, double r, ui.Image im) {
    canvas.save();
    canvas.clipPath(Path()..addOval(Rect.fromCircle(center: c, radius: r)));
    paintImage(
        canvas: canvas,
        rect: Rect.fromCircle(center: c, radius: r),
        image: im,
        fit: BoxFit.cover);
    canvas.restore();
  }

  // ───────────────────────── من ─────────────────────────

  void _drawMe(Canvas canvas, Color tc) {
    final me = state.me;
    final c = Offset(me.x, me.y);
    final r = me.radius;
    final u = userFrequencyState(state);
    final band = kFreqBands[u.band]!;
    _aura(canvas, c, r, u);
    _halo(canvas, c, hexColor(band.color), r, 1, u.band);
    final meColor = hexColor(me.color.isEmpty ? band.color : me.color);
    _addCircleBounds(c, r);
    hits.add(HitEntry(
        type: 'me', id: '', kind: HitKind.node, center: c, radius: r));

    if (me.images.isEmpty) {
      canvas.drawCircle(c, r, Paint()..color = meColor);
      canvas.drawCircle(
          c,
          r,
          Paint()
            ..style = PaintingStyle.stroke
            ..strokeWidth = 3.5
            ..color = meColor);
      final s = r * 0.42, cy2 = c.dy - r * 0.12;
      final pp = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..color = withOp(tc, 0.85);
      drawDashed(
          canvas,
          Path()..addOval(Rect.fromCircle(center: Offset(c.dx, cy2), radius: s)),
          pp,
          [4, 3]);
      final lp = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.4
        ..strokeCap = StrokeCap.round
        ..color = withOp(tc, 0.85);
      canvas.drawLine(
          Offset(c.dx - s * 0.5, cy2), Offset(c.dx + s * 0.5, cy2), lp);
      canvas.drawLine(
          Offset(c.dx, cy2 - s * 0.5), Offset(c.dx, cy2 + s * 0.5), lp);
      drawText(canvas, me.name, c.dx, c.dy + r * 0.62,
          size: math.max(9, state.fontSize - 4),
          color: tc,
          weight: FontWeight.w700);
    } else {
      final im = images.get(me.images.first.src);
      if (im != null) {
        _circleImage(canvas, c, r, im);
      } else {
        canvas.drawCircle(c, r, Paint()..color = withOp(meColor, 0.4));
      }
      canvas.drawCircle(
          c,
          r,
          Paint()
            ..style = PaintingStyle.stroke
            ..strokeWidth = 3.5
            ..color = meColor);
      final lr = drawText(canvas, me.name, c.dx + me.labelDX,
          c.dy + 6 + me.labelDY,
          size: me.labelSize ?? _labelSize('me'),
          color: tc,
          weight: FontWeight.w700,
          outline: 3);
      if (me.name.isNotEmpty) {
        hits.add(
            HitEntry(type: 'me', id: '', kind: HitKind.label, rect: lr));
      }
    }
  }

  void _nodeIcon(Canvas canvas, Offset c, double r0, List<ImageItem> imgs,
      String icon, Color color, double iconScale, Color tc) {
    final r = r0 * iconScale;
    if (imgs.isNotEmpty && imgs.first.src.isNotEmpty) {
      final im = images.get(imgs.first.src);
      if (im != null) {
        _circleImage(canvas, c, r, im);
        canvas.drawCircle(
            c,
            r,
            Paint()
              ..style = PaintingStyle.stroke
              ..strokeWidth = 2
              ..color = withOp(color, 0.55));
      } else {
        canvas.drawCircle(c, r, Paint()..color = withOp(color, 0.4));
      }
    } else if (icon.trim().isNotEmpty) {
      drawText(canvas, icon, c.dx, c.dy,
          size: r * 1.7, color: tc, vCenter: true);
    } else {
      canvas.drawCircle(c, r, Paint()..color = withOp(color, 0.85));
    }
  }

  // ───────────────────────── هدف ─────────────────────────

  void _drawGoal(Canvas canvas, Goal g, Color tc) {
    final r0 = g.radius;
    final c = Offset(g.x, g.y);
    final col = hexColor(g.color, hexColor(kPalette[0]));
    _halo(canvas, c, col, r0 * math.max(1.0, g.iconScale), 1, g.freq);
    _nodeIcon(canvas, c, r0, g.images, g.icon, col, g.iconScale, tc);
    final r = r0 * g.iconScale;
    _addCircleBounds(c, r);
    hits.add(HitEntry(
        type: 'goal',
        id: g.id,
        kind: HitKind.node,
        center: c,
        radius: math.max(r, r0) + 8));

    var off = -(r0 + 22);
    if (r > r0) off += (off < 0 ? -1 : 1) * (r - r0);
    final lr = drawText(
        canvas, g.name, c.dx + g.labelDX, c.dy + off + g.labelDY,
        size: g.labelSize ?? _labelSize('goal'),
        color: tc,
        weight: FontWeight.w600,
        outline: 3);
    if (g.name.isNotEmpty) {
      hits.add(HitEntry(
          type: 'goal', id: g.id, kind: HitKind.label, rect: lr));
    }

    if ((state.showDateStamps || state.showTimeStamps) &&
        g.createdAt != null &&
        g.createdAt! > 0) {
      final stamp = _formatStamp(g.createdAt!);
      if (stamp.isNotEmpty) {
        drawText(
            canvas,
            stamp,
            c.dx + g.labelDX,
            c.dy + off + g.labelDY + (g.labelSize ?? _labelSize('goal')) * 1.15,
            size: math.max(9, (g.labelSize ?? _labelSize('goal')) * 0.62),
            color: withOp(tc, 0.6),
            weight: FontWeight.w400,
            outline: 2);
      }
    }

    final freq = kFreqBands[g.freq] ?? kFreqBands['alpha']!;
    double sumW(List<ActionNode> l) =>
        l.fold(0.0, (s, a) => s + a.weight + sumW(a.children));
    final power = math.min(100, (sumW(g.actions) * 3).round());
    final has = g.actions.isNotEmpty;
    final hud = (g.collapsed && has)
        ? 'رشد $power٪'
        : '${freq.label} — ${freq.desc} · رشد $power٪';
    drawText(canvas, hud, c.dx, c.dy + r0 + (has ? 46 : 42),
        size: 11, color: withOp(tc, 0.6), weight: FontWeight.w400);
    _goalShutter(canvas, g, col, tc);
  }

  void _goalShutter(Canvas canvas, Goal g, Color col, Color tc) {
    final n = goalBranchCount(state, g);
    if (n == 0) return;
    final cx = g.x, cy = g.y + g.radius + 15;
    final open = !g.collapsed;
    hits.add(HitEntry(
        type: 'goalToggle',
        id: g.id,
        kind: HitKind.handle,
        rect: Rect.fromLTWH(cx - 34, cy - 19, 68, 38)));
    final pill = RRect.fromRectAndRadius(
        Rect.fromLTWH(cx - 27, cy - 11, 54, 22), const Radius.circular(11));
    final ink = open ? tc : const Color(0xFF1B1400);
    if (!open) canvas.drawRRect(pill, Paint()..color = withOp(col, 0.92));
    canvas.drawRRect(
        pill,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.6
          ..color = withOp(col, open ? 0.75 : 1.0));
    final chev = Path();
    if (open) {
      chev
        ..moveTo(-4, 1.8)
        ..lineTo(0, -2.2)
        ..lineTo(4, 1.8);
    } else {
      chev
        ..moveTo(-4, -1.8)
        ..lineTo(0, 2.2)
        ..lineTo(4, -1.8);
    }
    canvas.drawPath(
        chev.shift(Offset(cx - 14, cy)),
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2
          ..strokeCap = StrokeCap.round
          ..strokeJoin = StrokeJoin.round
          ..color = withOp(ink, open ? 0.75 : 0.95));
    drawText(canvas, toFa(n), cx + 7, cy + 4.3,
        size: 12,
        color: withOp(ink, open ? 0.8 : 1.0),
        weight: FontWeight.w700);
  }

  void _drawRing(Canvas canvas, Ring r, Color tc) {
    final c = Offset(r.x, r.y);
    final rad = r.radius;
    final col = hexColor(r.color, hexColor(kRingColor));
    final big = rad * math.max(1.0, r.iconScale);
    _halo(canvas, c, col, big, 1.2, null);
    _nodeIcon(canvas, c, rad, r.images, r.icon, col, r.iconScale, tc);
    _addCircleBounds(c, rad * r.iconScale);
    hits.add(HitEntry(
        type: 'ring',
        id: r.id,
        kind: HitKind.node,
        center: c,
        radius: math.max(big, rad) + 8));

    if (r.label.isNotEmpty) {
      final lines = wrapText(r.label, 16);
      final lx = c.dx + r.labelDX;
      final ly = c.dy - (big + 20) + r.labelDY;
      Rect? lr;
      for (var i = 0; i < lines.length; i++) {
        final b = drawText(canvas, lines[i], lx, ly + i * 16,
            size: r.labelSize ?? _labelSize('ring'),
            color: col,
            weight: FontWeight.w700,
            outline: 3);
        lr = lr == null ? b : lr.expandToInclude(b);
      }
      if (lr != null) {
        hits.add(HitEntry(
            type: 'ring', id: r.id, kind: HitKind.label, rect: lr));
      }
    }
    if (r.note.isNotEmpty) {
      final lines = wrapText(r.note, 22);
      final ly = c.dy + big + 18;
      for (var i = 0; i < lines.length; i++) {
        drawText(canvas, lines[i], c.dx, ly + i * 16,
            size: _fs() - 3,
            color: tc,
            weight: FontWeight.w400,
            outline: 2.5);
      }
    }
  }

  // ───────────────────────── تنه ─────────────────────────

  void _branches(Canvas canvas, MapHost h, Color tc,
      {required bool trunkOnly}) {
    final cp = geo.trunkControlPoints(h, state.me);
    final col =
        hexColor(h.color, hexColor(h.isRing ? kRingColor : kPalette[0]));
    if (h.isRing) {
      _taperedBezier(canvas, cp, col, 3.2, 1.6, 0.6);
    } else {
      final ts = (h is Goal && h.trunkStyle.isNotEmpty)
          ? h.trunkStyle
          : state.trunkStyle;
      _trunk(canvas, cp, col, kTrunkStyles.containsKey(ts) ? ts : 'dashed');
    }
    _pts..add(cp.p0)..add(cp.p3);

    if (h is Goal) {
      if (!h.collapsed) {
        _walker(canvas, h, cp, col);
      }
      _goalTrophy(canvas, h, col);
    }

    if (trunkOnly) return;
    final acts = _visibleActs(h.actions);
    for (var i = 0; i < acts.length; i++) {
      final t = math.min(0.9, 0.15 + i * 0.09);
      _twig(canvas, h, col, cp.at(t), cp.tangent(t), acts[i],
          i.isEven ? 1 : -1, 1.0, tc,
          trunk: cp, trunkT: t);
    }
  }

  Paint _stroke(Color col, double w, double op,
          {StrokeCap cap = StrokeCap.round}) =>
      Paint()
        ..style = PaintingStyle.stroke
        ..color = withOp(col, op)
        ..strokeWidth = w
        ..strokeCap = cap
        ..strokeJoin = StrokeJoin.round;

  Path _pathOf(geo.Cubic k) => Path()
    ..moveTo(k.p0.dx, k.p0.dy)
    ..cubicTo(k.p1.dx, k.p1.dy, k.p2.dx, k.p2.dy, k.p3.dx, k.p3.dy);

  void _trunk(Canvas c, geo.Cubic cp, Color col, String style) {
    switch (style) {
      case 'solid':
        c.drawPath(_pathOf(cp), _stroke(col, 3, 0.9));
      case 'dotted':
        drawDashed(c, _pathOf(cp), _stroke(col, 3.6, 0.9), [0.1, 8]);
      case 'dashdot':
        drawDashed(c, _pathOf(cp),
            _stroke(col, 3, 0.9, cap: StrokeCap.butt), [14, 7, 2, 7]);
      case 'long':
        drawDashed(c, _pathOf(cp),
            _stroke(col, 3, 0.9, cap: StrokeCap.butt), [26, 13]);
      case 'double':
        {
          final d = cp.p3 - cp.p0;
          final len = d.distance == 0 ? 1.0 : d.distance;
          final n = Offset(-d.dy / len * 2.6, d.dx / len * 2.6);
          for (final k in [1.0, -1.0]) {
            final o = n * k;
            c.drawPath(
                _pathOf(geo.Cubic(cp.p0 + o, cp.p1 + o, cp.p2 + o, cp.p3 + o)),
                _stroke(col, 1.6, 0.9));
          }
        }
      case 'glow':
        c.drawPath(_pathOf(cp), _stroke(col, 9, 0.16));
        c.drawPath(_pathOf(cp), _stroke(col, 2.8, 0.95));
      case 'taper':
        _taperedBezier(c, cp, col, 5.2, 1.6, 0.9);
      default:
        drawDashed(c, _pathOf(cp),
            _stroke(col, 3, 0.9, cap: StrokeCap.butt), [9, 9]);
    }
  }

  void _taperedBezier(
      Canvas c, geo.Cubic cp, Color col, double w0, double w1, double op) {
    const seg = 7;
    final p = _stroke(col, w0, op);
    for (var s = 0; s < seg; s++) {
      p.strokeWidth = w0 + (w1 - w0) * ((s + 0.5) / seg);
      c.drawLine(cp.at(s / seg), cp.at((s + 1) / seg), p);
    }
  }

  void _taperedPoly(
      Canvas c, List<Offset> pts, Color col, double w0, double w1, double op) {
    final cum = geo.polyCum(pts);
    final tot = cum.last == 0 ? 1.0 : cum.last;
    final p = _stroke(col, w0, op);
    for (var i = 1; i < pts.length; i++) {
      final f = ((cum[i - 1] + cum[i]) / 2) / tot;
      p.strokeWidth = w0 + (w1 - w0) * f;
      c.drawLine(pts[i - 1], pts[i], p);
    }
  }

  // ───────────────────────── شمارش لاگ ─────────────────────────

  static int _jalaliDayNum(String jk) {
    final p = jk.split('-').map((e) => int.tryParse(e) ?? 0).toList();
    if (p.length != 3) return 0;
    const cum = [0, 31, 62, 93, 124, 155, 186, 216, 246, 276, 306, 336];
    final jy = p[0];
    final jm = p[1].clamp(1, 12);
    final jd = p[2];
    return jy * 365 + cum[jm - 1] + jd;
  }

  static bool _isDoneLog(dynamic v) =>
      v == true ||
      v == 'انجام شد ✓' ||
      (v is String && v.isNotEmpty);

  int _logCount(ActionNode a) {
    var n = 0;
    for (final v in a.logs.values) {
      if (_isDoneLog(v)) n++;
    }
    return n;
  }

  int _goalTotalLogs(Goal g) {
    var n = 0;
    void walk(List<ActionNode> list) {
      for (final a in list) {
        n += _logCount(a);
        walk(a.children);
      }
    }
    walk(g.actions);
    return n;
  }

  // ───────────────────────── شکل قدم ─────────────────────────

  Path _footPath(double size) {
    final s = size / 16.0;
    final p = Path();
    p.addOval(Rect.fromCenter(
      center: Offset(0, -3 * s),
      width: 8 * s,
      height: 11 * s,
    ));
    p.addOval(Rect.fromCenter(
      center: Offset(0, 5.5 * s),
      width: 6 * s,
      height: 4.5 * s,
    ));
    const toesX = [-3.2, -1.6, 0.0, 1.5, 2.8];
    const toesY = [-8.5, -9.5, -9.8, -9.3, -8.3];
    const toesR = [1.15, 1.30, 1.35, 1.25, 1.05];
    for (var i = 0; i < 5; i++) {
      p.addOval(Rect.fromCircle(
        center: Offset(toesX[i] * s, toesY[i] * s),
        radius: toesR[i] * s,
      ));
    }
    return p;
  }

  void _drawFoot(
    Canvas canvas,
    Offset pos,
    double angle,
    double size,
    Color color, {
    bool outline = false,
    double strokeW = 1.4,
  }) {
    canvas.save();
    canvas.translate(pos.dx, pos.dy);
    canvas.rotate(angle);
    final path = _footPath(size);
    if (outline) {
      canvas.drawPath(
        path,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = strokeW
          ..strokeJoin = StrokeJoin.round
          ..strokeCap = StrokeCap.round
          ..color = color,
      );
    } else {
      canvas.drawPath(path, Paint()..color = color);
    }
    canvas.restore();
  }

  // ───────────────────────── قدم‌زن روی تنه ─────────────────────────

  /// قدم‌زن: بدنه‌ی گرد + دو پا + دنباله‌ی پاهای محو.
  /// - بدنه بین من و هدف با سرعت طبیعی حرکت رفت و برگشتی دارد.
  /// - دو پا با فاز نصف جابجا می‌شوند.
  /// - پایی که می‌رود جلو از زمین کنده می‌شود (lift).
  /// - دنباله‌ی ۵ قدم پشت سرش محو می‌شوند.
  void _walker(Canvas canvas, Goal g, geo.Cubic cp, Color col) {
    if (_goalTotalLogs(g) == 0) return;

    final playing = g.extra['walkerPlaying'] as bool? ?? true;
    final speed =
        ((g.extra['walkerSpeed'] as num?)?.toDouble() ?? 1.5).clamp(0.3, 4.0);
    final manualT = (g.extra['walkerPos'] as num?)?.toDouble();

    const totalSteps = 20;
    const stepLen = 1.0 / totalSteps;

    // ─── موقعیت بدنه ───
    double bodyT;
    if (playing) {
      final tSteps = _t * speed;
      final cycleLen = totalSteps * 2.0;
      final cycle = tSteps % cycleLen;
      double stepNum;
      if (cycle < totalSteps) {
        stepNum = cycle;
      } else {
        stepNum = cycleLen - cycle;
      }
      final norm = (stepNum / totalSteps).clamp(0.0, 1.0);
      bodyT = 0.06 + norm * 0.88;
    } else {
      bodyT = (manualT ?? 0.5).clamp(0.06, 0.94);
    }

    // ─── فاز قدم ───
    final stepPhase = playing ? (_t * speed) % 1.0 : 0.0;
    final leftSwinging = stepPhase < 0.5;
    final swingPhase = leftSwinging ? stepPhase * 2 : (stepPhase - 0.5) * 2;
    final swingEase = _easeInOut(swingPhase);

    // ─── موقعیت پاها ───
    final footGap = stepLen * 0.45;
    final plantedT = (bodyT - footGap).clamp(0.05, 0.95);
    final swingStart = (bodyT - footGap).clamp(0.05, 0.95);
    final swingEnd = (bodyT + footGap).clamp(0.05, 0.95);
    final swingingT = swingStart + (swingEnd - swingStart) * swingEase;

    final leftT = leftSwinging ? swingingT : plantedT;
    final rightT = leftSwinging ? plantedT : swingingT;

    const maxLift = 5.0;
    final leftLift =
        leftSwinging ? math.sin(swingPhase * math.pi) * maxLift : 0.0;
    final rightLift =
        leftSwinging ? 0.0 : math.sin(swingPhase * math.pi) * maxLift;

    final baseSize = 20.0 * state.footScale.clamp(0.4, 3.0);

    // ─── دنباله ───
    for (var i = 1; i <= 5; i++) {
      final trailT = (bodyT - i * stepLen).clamp(0.02, 0.98);
      if (trailT <= 0.03) continue;
      final trailSize = baseSize * (0.5 - i * 0.06);
      final trailOpacity = (1.0 - i / 6.0) * 0.42;
      final trailIsLeft = (i + (leftSwinging ? 0 : 1)) % 2 == 0;
      _drawWalkerFoot(canvas, cp, trailT, trailIsLeft ? -1.0 : 1.0,
          trailSize, withOp(col, trailOpacity),
          lift: 0, outline: true);
    }

    // ─── دو پا ───
    _drawWalkerFoot(canvas, cp, leftT, -1.0, baseSize, withOp(col, 0.92),
        lift: leftLift);
    _drawWalkerFoot(canvas, cp, rightT, 1.0, baseSize, withOp(col, 0.92),
        lift: rightLift);

    // ─── بدنه ───
    final bodyPt = cp.at(bodyT);
    final bodyAng = cp.tangent(bodyT);

    final bobFreq = speed * 2;
    final bobPhase = (_t * bobFreq * math.pi * 2) % (math.pi * 2);
    final bob = playing ? math.sin(bobPhase) * 1.5 : 0.0;
    final nx = -math.sin(bodyAng);
    final ny = math.cos(bodyAng);
    final bodyPos = Offset(bodyPt.dx + nx * bob, bodyPt.dy + ny * bob);

    final pulseRate = playing ? (1.0 + speed * 0.5) : 0.4;
    final pulse = 0.9 + math.sin(_t * pulseRate * 2 * math.pi) * 0.1;
    final bodyR = 8.0 * pulse;

    canvas.drawCircle(
        bodyPos,
        bodyR * 2.6,
        Paint()
          ..color = withOp(col, 0.20)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 14));

    canvas.drawCircle(
        bodyPos,
        bodyR * 1.35,
        Paint()
          ..color = withOp(col, 0.18)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6));

    canvas.drawCircle(
        bodyPos,
        bodyR,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2.0
          ..color = withOp(col, 0.92));

    canvas.drawCircle(
        bodyPos, bodyR * 0.42, Paint()..color = withOp(col, 0.92));

    if (!playing) {
      final r = bodyR * 0.32;
      canvas.drawRect(
        Rect.fromCenter(center: bodyPos, width: r, height: r),
        Paint()..color = withOp(col, 0.92),
      );
    }

    hits.add(HitEntry(
      type: 'walker',
      id: g.id,
      hostId: g.id,
      kind: HitKind.handle,
      center: bodyPos,
      radius: baseSize * 1.4,
    ));
  }

  void _drawWalkerFoot(
    Canvas canvas,
    geo.Cubic cp,
    double t,
    double side,
    double size,
    Color color, {
    double lift = 0,
    bool outline = false,
  }) {
    final pt = cp.at(t);
    final ang = cp.tangent(t);
    final nx = -math.sin(ang);
    final ny = math.cos(ang);
    final sideOffset = size * 0.32 * side;
    final total = sideOffset + lift;
    final pos = Offset(pt.dx + nx * total, pt.dy + ny * total);
    _drawFoot(canvas, pos, ang + math.pi / 2, size, color,
        outline: outline, strokeW: outline ? 1.2 : 1.4);
  }

  // ───────────────────────── جام ─────────────────────────

  void _goalTrophy(Canvas canvas, Goal g, Color col) {
    if (g.extra['trophyVisible'] == false) return;

    final totalLogs = _goalTotalLogs(g);
    if (totalLogs == 0) return;

    final progress = (totalLogs / 30.0).clamp(0.0, 1.0);

    final cx = g.x + g.radius + 34;
    final cy = g.y - g.radius - 34;

    final pulse = 0.9 + math.sin(_t * 2.2) * 0.1;
    final size = 26.0 * pulse;

    canvas.drawCircle(
      Offset(cx, cy),
      size * 1.7,
      Paint()
        ..color = withOp(col, 0.15 + 0.35 * progress)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 14),
    );

    canvas.drawCircle(
      Offset(cx, cy),
      size * 0.95,
      Paint()
        ..color = withOp(col, 0.35 + 0.5 * progress)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6),
    );

    final rayPaint = Paint()
      ..color = withOp(col, 0.7)
      ..strokeWidth = 1.6
      ..strokeCap = StrokeCap.round;
    for (var i = 0; i < 8; i++) {
      final a = (i / 8) * math.pi * 2 + _t * 0.5;
      final r1 = size * 1.1;
      final r2 = size * (1.3 + math.sin(_t * 3 + i) * 0.15);
      canvas.drawLine(
        Offset(cx + math.cos(a) * r1, cy + math.sin(a) * r1),
        Offset(cx + math.cos(a) * r2, cy + math.sin(a) * r2),
        rayPaint,
      );
    }

    _drawEmoji(canvas, Offset(cx, cy), 0, size, col, '🏆');

    drawText(
      canvas,
      '${(progress * 100).round()}٪',
      cx,
      cy + size * 0.95,
      size: 11,
      color: withOp(col, 0.85),
      weight: FontWeight.w700,
      outline: 2,
    );

    hits.add(HitEntry(
      type: 'trophy',
      id: g.id,
      hostId: g.id,
      kind: HitKind.handle,
      center: Offset(cx, cy),
      radius: size * 1.2,
    ));
  }

  // ───────────────────────── ردپای شاخه ─────────────────────────

  void _footprints(Canvas canvas, geo.TwigGeom geom, geo.Cubic cub,
      ActionNode a, Color color, double scale) {
    final length = (geom.end - geom.originPt).distance;
    if (length < 22) return;

    final entries = a.logs.entries.toList();
    if (entries.isEmpty) return;

    final days = <String, int>{};
    for (final e in entries) {
      days[e.key] = _jalaliDayNum(e.key);
    }
    entries.sort((x, y) => days[x.key]!.compareTo(days[y.key]!));

    final firstDay = days[entries.first.key]!;
    final lastDay = days[entries.last.key]!;
    final span = (lastDay - firstDay).abs() + 1;

    final sizeMul = state.footScale.clamp(0.4, 3.0);
    final footMul = (a.footSize ?? 1.0).clamp(0.4, 2.5);
    final fs = math.max(11.0, 15.0 * scale) * sizeMul * footMul;

    if (span <= 1) {
      final e = entries.first;
      if (_isDoneLog(e.value)) {
        _drawFoot(canvas, geom.end, cub.tangent(1.0) + math.pi / 2, fs,
            withOp(color, 0.85));
      }
      return;
    }

    final doneCount = entries.where((e) => _isDoneLog(e.value)).length;
    if (doneCount == 0) return;
    final baseProgress = (doneCount / 30.0).clamp(0.25, 1.0);

    final todayDay = _jalaliDayNum(jKey(DateTime.now()));

    for (var i = 0; i < entries.length; i++) {
      final e = entries[i];
      final day = days[e.key]!;
      final isDone = _isDoneLog(e.value);
      final isMissed = e.value == false;

      final t = 0.06 + (day - firstDay) / span * 0.88;

      Offset pt;
      double ang;
      if (geom.poly != null) {
        final q = geo.polyPointAt(geom.poly!, t);
        pt = q.pt;
        ang = q.angle;
      } else {
        pt = cub.at(t);
        ang = cub.tangent(t);
      }

      final daysFromToday = (todayDay - day).abs();
      double recency;
      if (daysFromToday <= 2) {
        recency = 1.0;
      } else if (daysFromToday <= 10) {
        recency = 0.75;
      } else {
        recency = 0.45;
      }
      final opacity = baseProgress * recency;

      final side = (i % 2 == 0) ? 1.0 : -1.0;
      final off = fs * 0.4 * side;
      final pos = pt + Offset(-math.sin(ang) * off, math.cos(ang) * off);

      if (isDone) {
        _drawFoot(canvas, pos, ang + math.pi / 2, fs,
            color.withAlpha((opacity * 255).round()));

        if (daysFromToday == 0) {
          canvas.drawCircle(
            pos,
            fs * 0.9,
            Paint()
              ..style = PaintingStyle.stroke
              ..strokeWidth = 1.6
              ..color = withOp(color, 0.75),
          );
        }
      } else if (isMissed) {
        canvas.drawCircle(
          pos,
          fs * 0.34,
          Paint()
            ..style = PaintingStyle.stroke
            ..strokeWidth = 1.2
            ..color = withOp(color, opacity * 0.6),
        );
      }
    }
  }

  // ───────────────────────── قدم متحرک روی شاخه ─────────────────────────

  void _walkingFoot({
    required Canvas canvas,
    required geo.Cubic cub,
    List<Offset>? poly,
    required Color color,
    required double baseSize,
    required ActionNode a,
    required String hostId,
  }) {
    final count = _logCount(a);
    if (count == 0) return;

    final sizeMul = state.footScale.clamp(0.4, 3.0);
    final footMul = (a.footSize ?? 1.0).clamp(0.4, 2.5);
    final size = baseSize * sizeMul * footMul;
    final progress = (count / 30.0).clamp(0.25, 1.0);

    double t;
    if (a.footPlaying) {
      final speedVal = (a.footSpeed ?? 1.0).clamp(0.2, 3.0);
      final secondsPerCycle = 4.6 / speedVal;
      final cycle = (_t / secondsPerCycle) % 1.0;

      double pingPong(double c) {
        if (c < 0.38) {
          final p = c / 0.38;
          return 1.0 - math.pow(1 - p, 3).toDouble();
        } else if (c < 0.5) {
          return 1.0;
        } else if (c < 0.88) {
          final p = (c - 0.5) / 0.38;
          return 1.0 - math.pow(p, 3).toDouble();
        } else {
          return 0.0;
        }
      }

      final journey = pingPong(cycle);
      t = 0.08 + journey * 0.84;
    } else {
      t = (a.footPos ?? 0.5).clamp(0.08, 0.92);
    }

    final stepPhase = a.footPlaying ? (_t / 0.5) % 1.0 : 0.25;
    final rightLeads = stepPhase < 0.5;
    const strideLen = 0.07;
    final tFront = t;
    final tBack = (t - strideLen).clamp(0.05, 0.95);
    final tRight = rightLeads ? tFront : tBack;
    final tLeft = rightLeads ? tBack : tFront;

    _drawFootAt(canvas, cub, poly, tRight, 1.0, size * 0.95, color, progress,
        a.footPlaying);
    _drawFootAt(canvas, cub, poly, tLeft, -1.0, size * 0.95, color,
        progress * 0.85, a.footPlaying);

    final mid = (tRight + tLeft) / 2;
    Offset hitPt;
    if (poly != null) {
      hitPt = geo.polyPointAt(poly, mid).pt;
    } else {
      hitPt = cub.at(mid);
    }
    hits.add(HitEntry(
      type: 'foot',
      id: a.id,
      hostId: hostId,
      kind: HitKind.handle,
      center: hitPt,
      radius: size * 1.4,
    ));
  }

  // ─────────────── قدم‌ها روی مسیر اصلی هدف ───────────────
  // n ثبت = (n-1) قدم ثابت از ابتدای شاخه روی تنه‌ی هدف + یک قدم متحرک
  // که در ادامه‌ی مسیر هدف راه می‌رود.
  void _trunkSteps(Canvas canvas, geo.Cubic trunk, double t0, ActionNode a,
      Color color, double baseSize, String hostId) {
    final n = _logCount(a);
    if (n == 0) return;

    final sizeMul = state.footScale.clamp(0.4, 3.0);
    final footMul = (a.footSize ?? 1.0).clamp(0.4, 2.5);
    final size = baseSize * sizeMul * footMul;
    final progress = (n / 30.0).clamp(0.25, 1.0);

    final fixed = n - 1;
    final stride = math.min(0.04, math.max(0.008, (0.80 - t0) / (fixed + 2)));

    // قدم‌های ثابت
    for (var k = 0; k < fixed; k++) {
      final t = (t0 + k * stride).clamp(0.02, 0.94);
      _drawFootAt(canvas, trunk, null, t, k.isEven ? 1.0 : -1.0, size * 0.95,
          color, progress * 0.8, false);
    }

    // قدم متحرک: از آخرین قدم ثابت تا نزدیک هدف
    final tMin = (t0 + fixed * stride).clamp(0.05, 0.9);
    final tMax = 0.94;
    double t;
    if (a.footPlaying) {
      final speedVal = (a.footSpeed ?? 1.0).clamp(0.2, 3.0);
      final secondsPerCycle = 4.6 / speedVal;
      final cycle = (_t / secondsPerCycle) % 1.0;
      double journey;
      if (cycle < 0.38) {
        journey = 1.0 - math.pow(1 - cycle / 0.38, 3).toDouble();
      } else if (cycle < 0.5) {
        journey = 1.0;
      } else if (cycle < 0.88) {
        journey = 1.0 - math.pow((cycle - 0.5) / 0.38, 3).toDouble();
      } else {
        journey = 0.0;
      }
      t = tMin + journey * (tMax - tMin);
    } else {
      t = tMin + (a.footPos ?? 0.5).clamp(0.0, 1.0) * (tMax - tMin);
    }

    final stepPhase = a.footPlaying ? (_t / 0.5) % 1.0 : 0.25;
    final rightLeads = stepPhase < 0.5;
    const strideLen = 0.04;
    final tFront = t;
    final tBack = (t - strideLen).clamp(0.02, 0.95);
    final tRight = rightLeads ? tFront : tBack;
    final tLeft = rightLeads ? tBack : tFront;
    _drawFootAt(canvas, trunk, null, tRight, 1.0, size * 0.95, color, progress,
        a.footPlaying);
    _drawFootAt(canvas, trunk, null, tLeft, -1.0, size * 0.95, color,
        progress * 0.85, a.footPlaying);

    hits.add(HitEntry(
      type: 'foot',
      id: a.id,
      hostId: hostId,
      kind: HitKind.handle,
      center: trunk.at((tRight + tLeft) / 2),
      radius: size * 1.4,
    ));
  }

  void _drawFootAt(Canvas canvas, geo.Cubic cub, List<Offset>? poly, double t,
      double side, double size, Color color, double opacity, bool playing) {
    Offset pt;
    double ang;
    if (poly != null) {
      final q = geo.polyPointAt(poly, t);
      pt = q.pt;
      ang = q.angle;
    } else {
      pt = cub.at(t);
      ang = cub.tangent(t);
    }

    final off = size * 0.4 * side;
    final pos = pt + Offset(-math.sin(ang) * off, math.cos(ang) * off);

    final glowAlpha = ((playing ? 110 : 50) * opacity).round();
    canvas.drawCircle(
      pos,
      size * 0.85,
      Paint()
        ..color = color.withAlpha(glowAlpha)
        ..maskFilter = MaskFilter.blur(BlurStyle.normal, playing ? 8 : 5),
    );

    if (!playing) {
      canvas.drawCircle(
        pos,
        size * 1.0,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.4
          ..color = withOp(color, 0.7 * opacity),
      );
    }

    _drawFoot(canvas, pos, ang + math.pi / 2, size * 1.1,
        color.withAlpha((255 * opacity).round()));
  }

  // ───────────────────────── کمکی ─────────────────────────

  void _drawEmoji(Canvas canvas, Offset at, double angle, double size,
      Color color, String emoji) {
    canvas.save();
    canvas.translate(at.dx, at.dy);
    canvas.rotate(angle);
    final tp = TextPainter(
      text: TextSpan(
        text: emoji,
        style: TextStyle(fontSize: size, color: color),
      ),
      textDirection: TextDirection.ltr,
    )..layout();
    tp.paint(canvas, Offset(-tp.width / 2, -tp.height / 2));
    canvas.restore();
  }

  List<ActionNode> _visibleActs(List<ActionNode> list) {
    final out = <ActionNode>[];
    for (final n in list) {
      if (n.extra['achieved'] == true) {
        out.addAll(_visibleActs(n.children));
      } else {
        out.add(n);
      }
    }
    return out;
  }

  void _routineRing(Canvas canvas, Offset center, double tipR, Color color,
      double scale, ActionNode a) {
    final R = tipR + 5.5 * math.max(0.8, scale);
    final sw = 2.2 * math.max(0.8, scale);
    final days = jalaaliCurrentWeekDates();
    final tKey = todayJK();
    final rect = Rect.fromCircle(center: center, radius: R);

    const step = 2 * math.pi / 7;
    const gap = 0.34;

    for (var i = 0; i < 7; i++) {
      final k = days[i];
      final has = truthy(a.logs[k]);
      final isToday = k == tKey;
      final a0 = -math.pi / 2 + i * step + gap / 2;
      final a1 = -math.pi / 2 + (i + 1) * step - gap / 2;
      final op = has ? 0.95 : (isToday ? 0.55 : 0.20);
      final paint = Paint()
        ..style = PaintingStyle.stroke
        ..strokeCap = StrokeCap.round
        ..strokeWidth = isToday ? sw * 1.45 : sw
        ..color = withOp(color, op);
      canvas.drawArc(rect, a0, a1 - a0, false, paint);
    }

    if (!truthy(a.logs[tKey])) {
      canvas.drawCircle(center, tipR * 0.55,
          Paint()..color = const Color(0xFF0A0C18).withAlpha(140));
    }

    final streak = routineStreak(a);
    if (streak >= 2) {
      final fs = 8.5 * math.max(0.9, scale);
      drawText(canvas, toFa(streak), center.dx, center.dy - R - 3.5,
          size: fs, color: color, weight: FontWeight.w700, outline: 2);
    }
  }

  void _twig(Canvas canvas, MapHost h, Color hostColor, Offset originPt,
      double originDir, ActionNode a, int side, double scale, Color tc,
      {geo.Cubic? trunk, double trunkT = 0.15}) {
    final weight = a.weight == 0 ? 5.0 : a.weight;
    final color = (a.color != null && a.color!.isNotEmpty)
        ? hexColor(a.color, hostColor)
        : hostColor;
    final isRoutine = a.isRoutine;
    final geom = geo.computeTwigGeom(h, a, originPt, originDir, side, scale);
    geo.applyBranchStyle(geom, geo.effBranchStyle(h, a), side);
    final end = geom.end;
    _pts.add(end);
    hits.geom[a.id] = ActionGeomEntry(h.id, geom.originPt, end, scale);
    hits.add(HitEntry(
        type: 'action',
        id: a.id,
        hostId: h.id,
        kind: HitKind.handle,
        center: end,
        radius: math.max(15.0, 18 * scale)));

    final baseW = math.max(1.0, (1.9 + weight * 1.05) * scale);
    final tipW = math.max(0.7, baseW * 0.38);
    final cub = geo.Cubic(geom.originPt, geom.c1, geom.c2, end);
    if (geom.poly != null) {
      _taperedPoly(canvas, geom.poly!, color, baseW, tipW, 0.92);
    } else {
      _taperedBezier(canvas, cub, color, baseW, tipW, 0.92);
    }

    if (trunk != null) {
      _trunkSteps(canvas, trunk, trunkT, a, color, 15.0 * scale, h.id);
    }

    final kids = _visibleActs(a.children);
    if (kids.isNotEmpty) {
      canvas.drawCircle(end, math.max(2.0, 2.6 * scale),
          _stroke(color, 1.2, 0.55));
      for (var i = 0; i < kids.length; i++) {
        final tt = 0.5 + ((i + 1) / (kids.length + 1)) * 0.45;
        Offset co;
        double cd;
        if (geom.poly != null) {
          final q = geo.polyPointAt(geom.poly!, tt);
          co = q.pt;
          cd = q.angle;
        } else {
          co = cub.at(tt);
          cd = cub.tangent(tt);
        }
        _twig(canvas, h, hostColor, co, cd, kids[i], i.isEven ? 1 : -1,
            scale * 0.72, tc,
            trunk: trunk, trunkT: trunkT);
      }
    } else if (a.images.isNotEmpty) {
      final radius = math.max(1.8, 2 + weight * 0.28 * scale);
      final cnt = math.min(a.images.length, 3);
      for (var i = 0; i < cnt; i++) {
        final e = a.images[i];
        final ang = (i / cnt) * math.pi * 2 - math.pi / 2;
        final off = Offset(math.cos(ang) * radius * 0.7 + e.dx,
            math.sin(ang) * radius * 0.7 + e.dy);
        final rect = Rect.fromCenter(
            center: end + off, width: e.size, height: e.size);
        final im = images.get(e.src);
        if (im != null) {
          paintImage(
              canvas: canvas, rect: rect, image: im, fit: BoxFit.contain);
        }
        hits.add(HitEntry(
            type: 'action',
            id: a.id,
            hostId: h.id,
            kind: HitKind.image,
            imgIdx: i,
            rect: rect));
      }
      if (a.images.length > 3) {
        drawText(canvas, '+${a.images.length - 3}', end.dx + radius * 0.7,
            end.dy + radius * 0.7 + 4,
            size: 10, color: tc, outline: 2);
      }
    } else {
      canvas.drawCircle(end, math.max(1.8, 2 + weight * 0.28 * scale),
          Paint()..color = color);
    }

    if (isRoutine) {
      final tipR = math.max(1.8, 2 + weight * 0.28 * scale);
      _routineRing(canvas, end, tipR, color, scale, a);
    }

    if (a.text.isNotEmpty) {
      final lines = wrapText(a.text,
          math.max(10, (18 * math.min(1.0, scale + 0.35)).round()));
      final right = kLabelRtlAnchor ? side > 0 : side < 0;
      final lx = end.dx + (side > 0 ? 8 : -8) + a.labelDX;
      final ly = end.dy + 4 + a.labelDY;
      final fs = a.labelSize ?? _labelSize('action', scale);
      Rect? lr;
      for (var i = 0; i < lines.length; i++) {
        final b = drawText(canvas, lines[i], lx, ly + i * 16,
            size: fs,
            color: tc,
            weight: FontWeight.w400,
            align: right ? LabelAlign.right : LabelAlign.left,
            outline: 2.5);
        lr = lr == null ? b : lr.expandToInclude(b);
      }
      if (lr != null) {
        hits.add(HitEntry(
            type: 'action',
            id: a.id,
            hostId: h.id,
            kind: HitKind.label,
            rect: lr));
      }

      final cAt = a.extra['createdAt'];
      if ((state.showDateStamps || state.showTimeStamps) &&
          cAt is num &&
          cAt > 0) {
        final stamp = _formatStamp(cAt.toInt());
        if (stamp.isNotEmpty) {
          drawText(canvas, stamp, lx, ly + lines.length * 16,
              size: math.max(9, fs * 0.62),
              color: withOp(tc, 0.6),
              weight: FontWeight.w400,
              align: right ? LabelAlign.right : LabelAlign.left,
              outline: 2);
        }
      }
    }
  }
}
