import 'dart:math' as math;
import 'dart:typed_data' show Float32List;
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import '../models/map_models.dart';
import 'camera.dart';
import 'geometry.dart' as geo;
import 'seeded.dart';

// ═══════════════════════════════════════════════════════════════════════════
//  دنیای در حال رشد 🌱🏡🚗
//  بیابانِ خشک و خالی؛ با ساعت‌های کاری که کاربر روی هر هدف می‌گذارد (ماه‌ها و
//  سال‌ها) کنارِ جاده‌ی همان هدف آهسته سبزی، گیاه، خانه و ماشین پیدا می‌شود.
//  شکلِ نهایی از روی یک «دانه‌ی تصادفیِ» ثابتِ هر کاربر ساخته می‌شود
//  (state.extra['worldSeed']) و قابل پیش‌بینی نیست؛ هر کاربر دنیای خودش را دارد.
//  برای خاموش‌کردن: state.extra['worldOff'] = true
// ═══════════════════════════════════════════════════════════════════════════

double _c01(double x) => x < 0 ? 0.0 : (x > 1 ? 1.0 : x);
double _ease(double x) {
  final t = _c01(x);
  return t * t * (3 - 2 * t);
}

/// دقیقه‌های کارِ یک شاخه (ثبت‌شده + تایمرِ روشن) به‌همراهِ همه‌ی زیرشاخه‌هایش
double actionTotalMinutes(ActionNode a) {
  var sec = 0.0;
  for (final v in a.time.values) {
    if (v is num) sec += v.toDouble();
  }
  final ts = a.timerStart ?? 0;
  if (ts > 0) sec += (DateTime.now().millisecondsSinceEpoch - ts) / 1000.0;
  var m = sec / 60.0;
  for (final k in a.children) {
    m += actionTotalMinutes(k);
  }
  return m;
}

// ───────────────────────── رنگ‌ها ─────────────────────────
const List<Color> _kHouse = [
  Color(0xFFF2D7B6), Color(0xFFE9B7A0), Color(0xFFCFE3F1), Color(0xFFF6E7A8),
  Color(0xFFD9C8EA), Color(0xFFBFE0C8), Color(0xFFF4C6C6), Color(0xFFE8E2D2),
];
const List<Color> _kRoof = [
  Color(0xFFB5523B), Color(0xFF7A4B8C), Color(0xFF3F6F9E), Color(0xFF8B5A2B),
  Color(0xFF2F7D6B), Color(0xFFB8862F),
];
const List<Color> _kCar = [
  Color(0xFFE5484D), Color(0xFF3B82F6), Color(0xFFF59E0B), Color(0xFF10B981),
  Color(0xFF8B5CF6), Color(0xFFEC4899), Color(0xFFF3F4F6), Color(0xFF334155),
];
const List<Color> _kFlower = [
  Color(0xFFFF6B8B), Color(0xFFFFC145), Color(0xFFB57BFF), Color(0xFFFFFFFF),
  Color(0xFFFF8F3F), Color(0xFF5BC0FF),
];
const List<List<Color>> _kGreens = [
  [Color(0xFF2E7D32), Color(0xFF5FB05F)],
  [Color(0xFF3C8D40), Color(0xFF8CCB6B)],
  [Color(0xFF1F7A55), Color(0xFF58BE8E)],
  [Color(0xFF557A2B), Color(0xFFA2C95B)],
];

// ───────────────────────── مدلِ دنیا ─────────────────────────
// انواع: ۰ چمن ۱ گل ۲ بوته ۳ درخت ۴ کاج ۵ برکه ۶ سنگ ۷ قارچ ۸ کاه ۹ نرده
// ۱۰ چراغ ۱۱ آسیاب ۱۲ مزرعه ۲۰ خانه ۲۱ خانه‌ی دوطبقه ۲۲ برج ۲۳ انبار
// ۳۰ بالن ۳۱ رنگین‌کمان ۳۲ بشقاب‌پرنده
//
// اصلِ کار: دنیا از یک بیابانِ خشک شروع می‌شود. برای هر هدف، کنارِ تنه‌ی «من ← هدف»
// (همان مسیری که کاربر با انگشت می‌سازد) یک جاده ساخته می‌شود؛ طولِ جاده با
// وقتی که روی همان هدف گذاشته شده کم‌کم زیاد می‌شود. سبزی، گیاه، خانه و ماشین
// فقط دورِ جاده‌ی همان هدف و خیلی آهسته (ماه‌ها و سال‌ها) پیدا می‌شوند.
// اگر هدفی پاک شود جاده و سبزیِ آن هم برمی‌گردد به بیابان.

/// دقیقه‌ی کارِ روی یک هدف تا جاده‌اش به طولِ کامل برسد (۴۰۰ ساعت)
const double _kRoadFull = 24000.0;
double _hr(double h) => h * 60.0;

class _El {
  _El(this.k, this.x, this.y, this.s, this.at, this.v, this.a);
  final int k;
  final double x, y, s, at, a;
  final int v;
}

/// المانِ وابسته به جاده: [sd] فاصله از ابتدای جاده، [off] فاصله‌ی عمودی از جاده
class _GEl {
  _GEl(this.k, this.sd, this.off, this.s, this.at, this.v, this.a);
  final int k;
  final double sd, off, s, at, a;
  final int v;
}

class _Blob {
  _Blob(this.sd, this.off, this.r, this.at, this.deep);
  final double sd, off, r, at;
  final bool deep;
}

class _GPlan {
  final List<_GEl> els = [];
  final List<_Blob> blobs = [];
  int theme = 0; // ۰ روستا ۱ جنگل ۲ مزرعه ۳ دریاچه
  double side = 1.0;
  // پیچ‌وتابِ جاده (ثابت برای هر هدف)
  double wobA = 50, wobP1 = 0, wobP2 = 0;
}

class _Plan {
  final List<_El> skyFlat = []; // رنگین‌کمان
  final List<_El> skyTall = []; // بالن، بشقاب‌پرنده (مختصات نسبت به «من»)
  List<Color> houseColors = [], roofColors = [], carColors = [];
}

class _RoadPoly {
  _RoadPoly._(this.pts, this.cum, this.length, this.bounds);
  final List<Offset> pts;
  final List<double> cum;
  final double length;
  final Rect bounds;
  static const double start = 62.0;

  static _RoadPoly? build(geo.Cubic cp, double off, _GPlan gp) {
    const n = 64;
    // طولِ تقریبیِ تنه برای تعیین تعدادِ پیچ‌ها
    var rawL = 0.0;
    var prev = cp.at(0);
    for (var i = 1; i < n; i++) {
      final q = cp.at(i / (n - 1));
      rawL += (q - prev).distance;
      prev = q;
    }
    final amp = math.min(gp.wobA, rawL * 0.16);
    final f1 = math.max(1.0, rawL / 420.0);
    final f2 = f1 * 1.7 + 0.35;
    final pts = <Offset>[];
    final cum = <double>[0.0];
    var minX = 1e12, minY = 1e12, maxX = -1e12, maxY = -1e12;
    for (var i = 0; i < n; i++) {
      final t = i / (n - 1);
      final p = cp.at(t);
      final a = cp.tangent(t);
      final w = amp *
          math.sin(math.pi * t) *
          (0.65 * math.sin(2 * math.pi * f1 * t + gp.wobP1) +
              0.35 * math.sin(2 * math.pi * f2 * t + gp.wobP2));
      final q = p + Offset(-math.sin(a), math.cos(a)) * (off + w);
      pts.add(q);
      if (q.dx < minX) minX = q.dx;
      if (q.dx > maxX) maxX = q.dx;
      if (q.dy < minY) minY = q.dy;
      if (q.dy > maxY) maxY = q.dy;
      if (i > 0) cum.add(cum.last + (pts[i] - pts[i - 1]).distance);
    }
    final len = cum.last - start - 44.0;
    if (len < 40) return null;
    return _RoadPoly._(pts, cum, len, Rect.fromLTRB(minX, minY, maxX, maxY));
  }

  int _seg(double d) {
    var lo = 1, hi = pts.length - 1;
    while (lo < hi) {
      final mid = (lo + hi) >> 1;
      if (cum[mid] >= d) {
        hi = mid;
      } else {
        lo = mid + 1;
      }
    }
    return lo;
  }

  Offset pos(double d) {
    final dd = (start + d).clamp(0.0, cum.last).toDouble();
    final i = _seg(dd);
    final seg = cum[i] - cum[i - 1];
    final f = seg == 0 ? 0.0 : (dd - cum[i - 1]) / seg;
    return Offset.lerp(pts[i - 1], pts[i], f)!;
  }

  double ang(double d) {
    final dd = (start + d).clamp(0.0, cum.last).toDouble();
    final i = _seg(dd);
    final v = pts[i] - pts[i - 1];
    return math.atan2(v.dy, v.dx);
  }

  /// مسیرِ جاده را تا طولِ [len] در [p] می‌ریزد
  void trace(Path p, double len) {
    final a = pos(0);
    p.moveTo(a.dx, a.dy);
    for (var i = 1; i < pts.length; i++) {
      final d = cum[i] - start;
      if (d <= 0) continue;
      if (d >= len) break;
      p.lineTo(pts[i].dx, pts[i].dy);
    }
    final e = pos(len);
    p.lineTo(e.dx, e.dy);
  }
}

class _Fr {
  _Fr(this.pl, this.road, this.gm, this.rl, this.paved, this.gi, this.end);
  final _GPlan pl;
  final _RoadPoly road;
  final double gm, rl, paved;
  final int gi;
  final Offset end;
}

class _Dr {
  _Dr(this.e, this.p);
  final _El e;
  final double p;
}

double _kindRadius(int k) {
  switch (k) {
    case 0:
    case 1:
    case 7:
      return 8;
    case 2:
      return 14;
    case 3:
      return 22;
    case 4:
      return 20;
    case 5:
      return 48;
    case 6:
      return 10;
    case 8:
      return 20;
    case 9:
      return 26;
    case 11:
      return 34;
    case 12:
      return 72;
    default:
      return 24;
  }
}

bool _isHeavy(int k) =>
    k == 3 || k == 4 || k == 8 || k == 11 || k == 20 || k == 21 || k == 22 || k == 23;

/// ساعتِ کارِ لازم روی هدف تا هر نوع پیدا شود (با کمی تصادفی)
double _baseHours(int k) {
  switch (k) {
    case 0:
      return 1.5;
    case 1:
      return 8;
    case 2:
      return 22;
    case 6:
      return 12;
    case 7:
      return 30;
    case 3:
      return 45;
    case 4:
      return 65;
    case 5:
      return 110;
    case 8:
      return 130;
    case 9:
      return 120;
    case 12:
      return 170;
    case 20:
      return 120;
    case 21:
      return 270;
    case 23:
      return 230;
    case 11:
      return 420;
    case 22:
      return 650;
    case 10:
      return 210;
    default:
      return 100;
  }
}

/// مدتی که هر نوع طول می‌کشد تا کاملاً بزرگ شود
double _rampMin(int k) {
  switch (k) {
    case 0:
    case 1:
    case 2:
    case 6:
    case 7:
      return _hr(4);
    case 3:
    case 4:
      return _hr(25);
    case 10:
      return _hr(3);
    default:
      return _hr(15);
  }
}

double _offFor(int k, double s, double Function() R) {
  switch (k) {
    case 0:
    case 1:
      return 24 + R() * 120;
    case 2:
      return 34 + R() * 90;
    case 6:
    case 7:
      return 30 + R() * 110;
    case 3:
    case 4:
      return 50 + R() * 110;
    case 8:
      return 50 + R() * 60;
    case 9:
      return 56 + R() * 8;
    case 11:
      return 85 + R() * 60;
    case 20:
    case 21:
    case 22:
      return 58 + R() * 22;
    case 23:
      return 72 + R() * 25;
    case 5:
    case 12:
      return 30 + _kindRadius(k) * s * 0.95 + R() * 25;
    default:
      return 50 + R() * 50;
  }
}

const List<int> _wKinds = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 11, 12, 20, 23];
const List<List<double>> _wTheme = [
  // روستا، جنگل، مزرعه، دریاچه
  [5, 5, 5, 5], // چمن
  [3, 2, 2, 3], // گل
  [1.5, 2, 1, 1.5], // بوته
  [1.5, 4, 1, 1.5], // درخت
  [0.5, 3, 0.3, 1], // کاج
  [0.2, 0.2, 0.2, 1.6], // برکه
  [1, 1, 1, 1], // سنگ
  [0.3, 1, 0.2, 0.3], // قارچ
  [0, 0, 1.3, 0], // کاه
  [0.3, 0, 1, 0.2], // نرده
  [0.06, 0, 0.3, 0.05], // آسیاب
  [0, 0, 1.2, 0], // مزرعه
  [1.6, 0.5, 0.8, 0.8], // خانه
  [0, 0, 0.7, 0], // انبار
];

int _pickKind(int theme, double Function() R) {
  var sum = 0.0;
  for (var i = 0; i < _wKinds.length; i++) {
    sum += _wTheme[i][theme];
  }
  var r = R() * sum;
  for (var i = 0; i < _wKinds.length; i++) {
    final w = _wTheme[i][theme];
    r -= w;
    if (r <= 0 && w > 0) return _wKinds[i];
  }
  return 0;
}

/// طرحِ ثابتِ دنیای یک هدف (فقط به شناسه‌ی هدف و دانه‌ی کاربر بستگی دارد)
_GPlan _genGoalPlan(String gid, int seed) {
  final rnd = seeded('w2-$seed-$gid');
  double R() => rnd();
  final pl = _GPlan();
  pl.theme = (R() * 4).floor().clamp(0, 3).toInt();
  pl.side = R() < 0.5 ? -1.0 : 1.0;
  pl.wobA = 45 + R() * 50;
  pl.wobP1 = R() * 6.28;
  pl.wobP2 = R() * 6.28;

  // لکه‌های سبزی کنارِ جاده: لایه‌ی روشن زودتر، لایه‌ی پررنگ خیلی دیرتر
  var sd = 30.0;
  while (sd < 4200) {
    final side = R() < 0.5 ? -1.0 : 1.0;
    pl.blobs.add(_Blob(
        sd, side * (10 + R() * 70), 55 + R() * 55, _hr(3 + R() * 30), false));
    if (R() < 0.55) {
      pl.blobs.add(_Blob(sd + R() * 30, -side * (10 + R() * 60),
          34 + R() * 36, _hr(70 + R() * 230), true));
    }
    sd += 48 + R() * 34;
  }

  // گیاه، خانه، برکه…
  var lastL = -999.0, lastR = -999.0, lastBig = -999.0;
  sd = 80 + R() * 20;
  while (sd < 4200) {
    final side = R() < 0.5 ? -1.0 : 1.0;
    var k = _pickKind(pl.theme, R);
    if (_isHeavy(k)) {
      final last = side < 0 ? lastL : lastR;
      if (sd - last < 70) {
        k = R() < 0.5 ? 0 : 1;
      } else if (side < 0) {
        lastL = sd;
      } else {
        lastR = sd;
      }
    }
    if ((k == 5 || k == 12)) {
      if (sd - lastBig < 260) {
        k = 2;
      } else {
        lastBig = sd;
      }
    }
    if (k == 20) {
      final q = R();
      if (q < 0.4) {
        k = 21;
      } else if (q > 0.93) {
        k = 22;
      }
    }
    final sz = (k == 5 || k == 12) ? 0.8 + R() * 0.8 : 0.8 + R() * 0.55;
    final at = _hr(_baseHours(k) * (0.7 + R() * 0.9));
    final off = side * _offFor(k, sz, R);
    pl.els.add(_GEl(k, sd, off, sz, at, (R() * 1000).floor(), R() * 6.28));
    if (R() < 0.45) {
      final k2 = R() < 0.6 ? 0 : 1;
      pl.els.add(_GEl(k2, sd + R() * 24, -side * (20 + R() * 70),
          0.8 + R() * 0.55, _hr(_baseHours(k2) * (0.7 + R() * 0.9)),
          (R() * 1000).floor(), R() * 6.28));
    }
    sd += 22 + R() * 30;
  }

  // چراغ‌های کنارِ جاده (فقط روی بخشِ آسفالت‌شده دیده می‌شوند)
  var ld = 150 + R() * 40;
  var ls = 1.0;
  while (ld < 4200) {
    pl.els.add(_GEl(10, ld, ls * 26.0, 1.0, _hr(210 + R() * 120), 0, R() * 6));
    ls = -ls;
    ld += 170 + R() * 60;
  }
  return pl;
}

/// رنگ‌ها و سورپرایزهای هر کاربر (نسبت به «من»؛ زمانشان بر حسبِ کلِ دقیقه‌ی کار)
_Plan _buildPlan(int seed) {
  final rnd = seeded('world-v2-$seed');
  double R() => rnd();
  final pl = _Plan();
  pl.houseColors = (List<Color>.from(_kHouse)..shuffle(math.Random(seed)))
      .take(4)
      .toList();
  pl.roofColors = (List<Color>.from(_kRoof)..shuffle(math.Random(seed + 7)))
      .take(3)
      .toList();
  pl.carColors = (List<Color>.from(_kCar)..shuffle(math.Random(seed + 13)))
      .take(5)
      .toList();

  Offset anyPos() {
    final ang = R() * math.pi * 2;
    final rr = 160 + R() * 420;
    return Offset(math.cos(ang) * rr, math.sin(ang) * rr);
  }

  if (R() < 0.75) {
    final at = _hr(300 + R() * 1200);
    final p = anyPos();
    pl.skyTall.add(_El(30, p.dx, p.dy, 1.0, at, 0, R() * 6));
  }
  if (R() < 0.6) {
    final at = _hr(150 + R() * 550);
    final p = anyPos();
    pl.skyFlat.add(_El(31, p.dx, p.dy, 0.9 + R() * 0.5, at, 0, R() * 6));
  }
  if (R() < 0.18) {
    final at = _hr(800 + R() * 1700);
    final p = anyPos();
    pl.skyTall.add(_El(32, p.dx, p.dy, 1.0, at, 0, R() * 6));
  }
  return pl;
}

// ───────────────────────── رسم ─────────────────────────
final Paint _p = Paint();
final Path _path = Path();

Paint _fill(Color c) => _p
  ..style = PaintingStyle.fill
  ..shader = null
  ..maskFilter = null
  ..color = c;

Paint _stroke(Color c, double w, {StrokeCap cap = StrokeCap.round}) => _p
  ..style = PaintingStyle.stroke
  ..shader = null
  ..maskFilter = null
  ..strokeWidth = w
  ..strokeCap = cap
  ..strokeJoin = StrokeJoin.round
  ..color = c;

class WorldLayer {
  /// مستطیلِ دیدِ فعلی به مختصاتِ «دنیا» (برای حذفِ چیزهای بیرون از صفحه)
  static Rect view = Rect.zero;

  static _Plan? _plan;
  static int _planSeed = 0;
  static final Map<String, _GPlan> _gPlans = {};
  static double _minutes = 0;
  static Map<String, double> _goalMin = {};
  static int _minMs = 0;

  /// کلِ دقیقه‌های کارِ کاربر روی همه‌ی هدف‌ها و حلقه‌ها (هر ۳۰۰ میلی‌ثانیه تازه می‌شود)
  static double totalMinutes(MapState s) {
    _refresh(s);
    return _minutes;
  }

  static void _refresh(MapState s) {
    final now = DateTime.now().millisecondsSinceEpoch;
    if (now - _minMs <= 300) return;
    final gm = <String, double>{};
    var tot = 0.0;
    for (final g in s.goals) {
      var m = 0.0;
      for (final a in g.actions) {
        m += actionTotalMinutes(a);
      }
      gm[g.id] = m;
      tot += m;
    }
    for (final r in s.rings) {
      for (final a in r.actions) {
        tot += actionTotalMinutes(a);
      }
    }
    _goalMin = gm;
    _minutes = tot;
    _minMs = now;
  }

  // لکه‌ی سبز: گرادیانِ واحد (کش‌شده) که با scale بزرگ می‌شود؛ ۸ سطحِ شفافیت
  static final Map<int, Paint> _blobPaints = {};
  static Paint _blobPaint(int level, bool deep, bool dark) {
    final key = level + (deep ? 10 : 0) + (dark ? 100 : 0);
    return _blobPaints.putIfAbsent(key, () {
      final a = level / 8.0 * (deep ? 0.34 : 0.38);
      final c0 = deep
          ? (dark
              ? Color.fromRGBO(40, 120, 60, a)
              : Color.fromRGBO(63, 150, 76, a))
          : (dark
              ? Color.fromRGBO(70, 150, 80, a)
              : Color.fromRGBO(120, 196, 106, a));
      final c1 = c0.withOpacity(0.0);
      return Paint()
        ..shader = ui.Gradient.radial(
            Offset.zero, 1.0, [c0, c1], const [0.0, 1.0]);
    });
  }

  static void _blob(Canvas c, Rect vv, Offset ce, double r, double k,
      bool deep, bool dark) {
    if (r < 4 || k <= 0.02) return;
    if (!vv.overlaps(Rect.fromCircle(center: ce, radius: r))) return;
    final level = (k * 8).ceil().clamp(1, 8).toInt();
    c.save();
    c.translate(ce.dx, ce.dy);
    c.scale(r, r);
    c.drawCircle(Offset.zero, 1.0, _blobPaint(level, deep, dark));
    c.restore();
  }

  static double _hf(int x, int y, int s, double k) {
    final v =
        math.sin(x * 12.9898 + y * 78.233 + s * 0.001237 + k * 37.719) *
            43758.5453;
    return v - v.floorToDouble();
  }

  /// جزئیاتِ بیابان: سنگ‌ریزه، بوته‌ی خشک، ترک؛ دورِ سبزی‌ها محو می‌شوند
  static void _desert(
      Canvas c, Rect vv, int seed, bool dark, List<double> gc) {
    const cell = 120.0;
    final x0 = (vv.left / cell).floor(), x1 = (vv.right / cell).floor();
    final y0 = (vv.top / cell).floor(), y1 = (vv.bottom / cell).floor();
    if ((x1 - x0 + 1) * (y1 - y0 + 1) > 1400) return;
    final dry = dark ? const Color(0x88A58E62) : const Color(0xAA9C8458);
    final peb = dark ? const Color(0x77746A58) : const Color(0x88B9AC93);
    final crk = dark ? const Color(0x55766A50) : const Color(0x66A89572);
    for (var ix = x0; ix <= x1; ix++) {
      for (var iy = y0; iy <= y1; iy++) {
        if (_hf(ix, iy, seed, 1.0) > 0.42) continue;
        final px = (ix + _hf(ix, iy, seed, 2.0)) * cell;
        final py = (iy + _hf(ix, iy, seed, 3.0)) * cell;
        var green = false;
        for (var i = 0; i < gc.length; i += 3) {
          final dx = gc[i] - px, dy = gc[i + 1] - py, rr = gc[i + 2];
          if (dx * dx + dy * dy < rr * rr) {
            green = true;
            break;
          }
        }
        if (green) continue;
        final ty = _hf(ix, iy, seed, 4.0);
        final sz = 0.7 + _hf(ix, iy, seed, 5.0) * 0.8;
        if (ty < 0.4) {
          c.drawOval(
              Rect.fromCenter(
                  center: Offset(px, py), width: 9 * sz, height: 5 * sz),
              _fill(peb));
        } else if (ty < 0.75) {
          final pa = _stroke(dry, 1.3);
          for (var j = -1; j <= 1; j++) {
            c.drawLine(Offset(px + j * 2.5 * sz, py),
                Offset(px + j * 5 * sz, py - (7 + (j == 0 ? 3 : 0)) * sz), pa);
          }
        } else {
          _path
            ..reset()
            ..moveTo(px - 14 * sz, py)
            ..lineTo(px - 5 * sz, py + 3 * sz)
            ..lineTo(px + 2 * sz, py - 2 * sz)
            ..lineTo(px + 12 * sz, py + 2 * sz);
          c.drawPath(_path, _stroke(crk, 1.1));
        }
      }
    }
  }

  static void paint(Canvas canvas, MapState s, CameraController cam,
      Size size, double t, bool isDark) {
    final sc = cam.scale <= 0 ? 1.0 : cam.scale;
    view = Rect.fromLTWH(
        -cam.x / sc, -cam.y / sc, size.width / sc, size.height / sc);
    if (s.extra['worldOff'] == true) return;

    var seed = 0;
    final sv = s.extra['worldSeed'];
    if (sv is num) {
      seed = sv.toInt();
    } else {
      seed = math.Random().nextInt(1 << 30) + 1;
      s.extra['worldSeed'] = seed;
    }
    if (_plan == null || _planSeed != seed) {
      _plan = _buildPlan(seed);
      _planSeed = seed;
      _gPlans.clear();
    }
    if (_gPlans.length > 80) _gPlans.clear();
    final pl = _plan!;
    _refresh(s);
    final tot = _minutes;
    final lod = sc < 0.22;
    final vv = view.inflate(100);
    final me = Offset(s.me.x, s.me.y);

    // ── جاده‌ی هر هدف ──
    final frs = <_Fr>[];
    for (var gi = 0; gi < s.goals.length; gi++) {
      final g = s.goals[gi];
      final gm = _goalMin[g.id] ?? 0.0;
      final gp = _gPlans.putIfAbsent(g.id, () => _genGoalPlan(g.id, seed));
      final cp = geo.trunkControlPoints(g, s.me);
      final road = _RoadPoly.build(cp, gp.side * 30.0, gp);
      if (road == null) continue;
      if (!vv.overlaps(road.bounds.inflate(260))) continue;
      final rl = math.min(
          road.length,
          14.0 +
              road.length *
                  math.pow(_c01(gm / _kRoadFull), 0.7).toDouble());
      final paved = road.length * _ease((gm - _hr(20)) / _hr(380));
      frs.add(_Fr(gp, road, gm, rl, paved, gi, Offset(g.x, g.y)));
    }

    // ── زمینِ خشک ──
    canvas.drawRect(
        vv,
        _fill(isDark
            ? const Color.fromRGBO(150, 125, 80, 0.10)
            : const Color.fromRGBO(214, 190, 140, 0.16)));

    // مرکزهای سبزی (برای محوِ جزئیاتِ بیابان)
    final gc = <double>[];
    final meK = _ease((tot - _hr(5)) / _hr(100));
    final meR = 70 + 170 * _ease(tot / _hr(500));
    if (meK > 0.02) gc.addAll([me.dx, me.dy, meR * 0.8]);
    for (final f in frs) {
      final rg = 50 + 130 * _ease(f.gm / _hr(120));
      for (var d = 0.0; d < f.rl; d += 80) {
        final q = f.road.pos(d);
        gc.addAll([q.dx, q.dy, rg]);
      }
    }
    if (!lod) _desert(canvas, vv, seed, isDark, gc);

    // ── سبزیِ آهسته: دورِ «من» و دورِ جاده‌ها ──
    _blob(canvas, vv, me, meR * (0.45 + 0.55 * meK), meK, false, isDark);
    for (final f in frs) {
      for (final b in f.pl.blobs) {
        if (b.sd > f.rl + 20) continue;
        final k = _ease((f.gm - b.at) / _hr(b.deep ? 100 : 60));
        if (k <= 0.02) continue;
        final base = f.road.pos(b.sd);
        final a = f.road.ang(b.sd);
        final ce = base + Offset(-math.sin(a), math.cos(a)) * b.off;
        _blob(canvas, vv, ce, b.r * (0.45 + 0.55 * k), k, b.deep, isDark);
      }
      // دورِ خودِ هدف
      final ke = _ease((f.gm - _hr(20)) / _hr(120));
      _blob(canvas, vv, f.end, 60 + 90 * _ease(f.gm / _hr(300)), ke, false,
          isDark);
    }

    // ── برکه‌ها، مزرعه‌ها، رنگین‌کمان (زیرِ همه) ──
    for (final f in frs) {
      for (final e in f.pl.els) {
        if (e.k != 5 && e.k != 12) continue;
        if (e.sd > f.rl - 6 || f.gm < e.at) continue;
        final a = f.road.ang(e.sd);
        final pos = f.road.pos(e.sd) +
            Offset(-math.sin(a), math.cos(a)) * e.off;
        if (!vv.contains(pos)) continue;
        final p = _ease((f.gm - e.at) / _rampMin(e.k));
        final el = _El(e.k, pos.dx, pos.dy, e.s, e.at, e.v, e.a);
        if (e.k == 5) {
          _pond(canvas, el, p, t);
        } else {
          _field(canvas, el, p);
        }
      }
    }
    for (final e in pl.skyFlat) {
      if (tot < e.at) continue;
      final p = _ease((tot - e.at) / _hr(8));
      _rainbow(canvas,
          _El(e.k, me.dx + e.x, me.dy + e.y, e.s, e.at, e.v, e.a), p);
    }

    // ── جاده‌ها (خاکی ← آسفالت) و ماشین‌ها ──
    for (final f in frs) {
      final road = f.road;
      _path.reset();
      road.trace(_path, road.length);
      canvas.drawPath(
          _path,
          _stroke(
              isDark ? const Color(0xFF6F6246) : const Color(0xFFD9C7A0), 26));
      canvas.drawPath(
          _path,
          _stroke(
              isDark ? const Color(0xFF5E5239) : const Color(0xFFC4A874), 20));
      if (f.paved >= 10) {
        _path.reset();
        road.trace(_path, f.paved);
        canvas.drawPath(
            _path,
            _stroke(
                isDark ? const Color(0xFF9CA3AF) : const Color(0xFFD5D9DF),
                30));
        canvas.drawPath(_path, _stroke(const Color(0xFF6B7280), 24));
        final dl = <double>[];
        for (var d = 12.0; d + 12 < f.paved; d += 26) {
          final a = road.pos(d), b = road.pos(d + 12);
          dl.addAll([a.dx, a.dy, b.dx, b.dy]);
        }
        if (dl.isNotEmpty) {
          canvas.drawRawPoints(ui.PointMode.lines, Float32List.fromList(dl),
              _stroke(const Color(0xCCFFFFFF), 2, cap: StrokeCap.butt));
        }
        // ماشین‌ها: فقط وقتی جاده آسفالت شده؛ با طولِ آسفالت بیشتر می‌شوند
        final nCar = math.min(4, (f.paved / 280).floor());
        if (f.paved > 140 && f.gm > _hr(200)) {
          for (var c = 0; c < nCar; c++) {
            final hsh =
                ((math.sin(f.gi * 7.31 + c * 12.9898) * 43758.5453) % 1.0)
                    .abs();
            final speed = 38 + hsh * 40;
            final dir = c.isEven ? 1.0 : -1.0;
            var d = (hsh * 1000 + t * speed * dir) % f.paved;
            if (d < 0) d += f.paved;
            final a = road.ang(d);
            final nrm = Offset(-math.sin(a), math.cos(a));
            final ps = road.pos(d) + nrm * (dir > 0 ? 7.0 : -7.0);
            if (!vv.contains(ps)) continue;
            _car(canvas, ps, dir > 0 ? a : a + math.pi,
                pl.carColors[(c + f.gi) % pl.carColors.length]);
          }
        }
      }
    }

    // ── بقیه‌ی چیزها (از بالا به پایین) ──
    final tall = <_Dr>[];
    for (final f in frs) {
      for (final e in f.pl.els) {
        if (e.k == 5 || e.k == 12) continue;
        if (f.gm < e.at) continue;
        if (e.k == 10) {
          if (e.sd > f.paved - 6) continue;
        } else if (e.sd > f.rl - 6) {
          continue;
        }
        if (lod && (e.k == 0 || e.k == 1 || e.k == 6 || e.k == 7)) continue;
        final p = _ease((f.gm - e.at) / _rampMin(e.k));
        if (p < 0.02) continue;
        final a = f.road.ang(e.sd);
        final pos = f.road.pos(e.sd) +
            Offset(-math.sin(a), math.cos(a)) * e.off;
        if (pos.dx < vv.left ||
            pos.dx > vv.right ||
            pos.dy < vv.top - 120 ||
            pos.dy > vv.bottom + 40) {
          continue;
        }
        tall.add(_Dr(_El(e.k, pos.dx, pos.dy, e.s, e.at, e.v, e.a), p));
      }
    }
    tall.sort((a, b) => a.e.y.compareTo(b.e.y));
    for (final d in tall) {
      final e = d.e;
      final p = d.p;
      switch (e.k) {
        case 0:
          _grass(canvas, e, p, t);
          break;
        case 1:
          _flower(canvas, e, p, t);
          break;
        case 2:
          _bush(canvas, e, p);
          break;
        case 3:
          _tree(canvas, e, p, t);
          break;
        case 4:
          _pine(canvas, e, p);
          break;
        case 6:
          _rock(canvas, e, p);
          break;
        case 7:
          _mushroom(canvas, e, p);
          break;
        case 8:
          _hay(canvas, e, p);
          break;
        case 9:
          _fence(canvas, e, p);
          break;
        case 10:
          _lamp(canvas, e, p, t);
          break;
        case 11:
          _windmill(canvas, e, p, t);
          break;
        case 20:
        case 21:
          _house(canvas, e, p, t, pl);
          break;
        case 22:
          _tower(canvas, e, p, t);
          break;
        case 23:
          _barn(canvas, e, p);
          break;
      }
    }

    // ── سورپرایزها: بالن و بشقاب‌پرنده ──
    for (final e in pl.skyTall) {
      if (tot < e.at) continue;
      final p = _ease((tot - e.at) / _hr(8));
      final el = _El(e.k, me.dx + e.x, me.dy + e.y, e.s, e.at, e.v, e.a);
      if (e.k == 30) {
        _balloon(canvas, el, p, t);
      } else {
        _ufo(canvas, el, p, t);
      }
    }

    // ── پرنده و ابر: خیلی دیر ──
    if (tot > _hr(200)) _birds(canvas, tot / 20.0, t, vv);
    if (tot > _hr(400)) _clouds(canvas, tot / 20.0, t, isDark, vv);
  }

  // ───────────── اجزا ─────────────

  static void _grass(Canvas c, _El e, double p, double t) {
    final s = e.s * p;
    final sw = math.sin(t * 1.5 + e.a) * 2 * s;
    final col = _kGreens[e.v % 4][0];
    final pa = _stroke(col, 1.6 * s);
    for (var i = -1; i <= 1; i++) {
      c.drawLine(Offset(e.x + i * 3 * s, e.y),
          Offset(e.x + i * 5 * s + sw, e.y - (8 + (i == 0 ? 3 : 0)) * s), pa);
    }
  }

  static void _flower(Canvas c, _El e, double p, double t) {
    final s = e.s * p;
    final sw = math.sin(t * 1.3 + e.a) * 1.5 * s;
    final top = Offset(e.x + sw, e.y - 12 * s);
    c.drawLine(Offset(e.x, e.y), top, _stroke(_kGreens[e.v % 4][0], 1.4 * s));
    final col = _kFlower[e.v % _kFlower.length];
    for (var i = 0; i < 5; i++) {
      final a = i * math.pi * 2 / 5;
      c.drawCircle(top + Offset(math.cos(a), math.sin(a)) * 2.6 * s, 2.1 * s,
          _fill(col));
    }
    c.drawCircle(top, 1.7 * s, _fill(const Color(0xFFFFD54F)));
  }

  static void _bush(Canvas c, _El e, double p) {
    final s = e.s * p;
    final g = _kGreens[e.v % 4];
    c.drawOval(
        Rect.fromCenter(
            center: Offset(e.x, e.y + 1.5 * s), width: 30 * s, height: 7 * s),
        _fill(const Color(0x22000000)));
    c.drawCircle(Offset(e.x - 7 * s, e.y - 5 * s), 7 * s, _fill(g[0]));
    c.drawCircle(Offset(e.x + 7 * s, e.y - 5 * s), 7 * s, _fill(g[0]));
    c.drawCircle(Offset(e.x, e.y - 8 * s), 9 * s, _fill(g[1]));
  }

  static void _tree(Canvas c, _El e, double p, double t) {
    final s = e.s * p;
    final g = _kGreens[e.v % 4];
    final sw = math.sin(t * 1.1 + e.a) * 1.6 * s;
    c.drawOval(
        Rect.fromCenter(
            center: Offset(e.x, e.y + 1.5 * s), width: 34 * s, height: 8 * s),
        _fill(const Color(0x25000000)));
    c.drawRect(Rect.fromLTWH(e.x - 2.5 * s, e.y - 16 * s, 5 * s, 16 * s),
        _fill(const Color(0xFF7A5230)));
    c.drawCircle(Offset(e.x - 9 * s + sw, e.y - 22 * s), 11 * s, _fill(g[0]));
    c.drawCircle(Offset(e.x + 9 * s + sw, e.y - 22 * s), 11 * s, _fill(g[0]));
    c.drawCircle(Offset(e.x + sw, e.y - 30 * s), 14 * s, _fill(g[1]));
    c.drawCircle(Offset(e.x + sw * 0.6, e.y - 24 * s), 10 * s, _fill(g[0]));
  }

  static void _pine(Canvas c, _El e, double p) {
    final s = e.s * p;
    final g = _kGreens[(e.v + 1) % 4];
    c.drawOval(
        Rect.fromCenter(
            center: Offset(e.x, e.y + 1.5 * s), width: 28 * s, height: 7 * s),
        _fill(const Color(0x25000000)));
    c.drawRect(Rect.fromLTWH(e.x - 2 * s, e.y - 8 * s, 4 * s, 8 * s),
        _fill(const Color(0xFF6B4423)));
    for (var i = 0; i < 3; i++) {
      final by = e.y - (6 + i * 11) * s;
      final w = (16 - i * 3.5) * s;
      _path
        ..reset()
        ..moveTo(e.x - w, by)
        ..lineTo(e.x, by - 18 * s)
        ..lineTo(e.x + w, by)
        ..close();
      c.drawPath(_path, _fill(i.isEven ? g[0] : g[1]));
    }
  }

  static void _rock(Canvas c, _El e, double p) {
    final s = e.s * p;
    c.drawOval(
        Rect.fromCenter(
            center: Offset(e.x, e.y - 3 * s), width: 16 * s, height: 10 * s),
        _fill(const Color(0xFF9AA3AE)));
    c.drawOval(
        Rect.fromCenter(
            center: Offset(e.x - 2 * s, e.y - 5 * s), width: 8 * s, height: 4 * s),
        _fill(const Color(0x66FFFFFF)));
  }

  static void _mushroom(Canvas c, _El e, double p) {
    final s = e.s * p;
    c.drawRect(Rect.fromLTWH(e.x - 1.5 * s, e.y - 6 * s, 3 * s, 6 * s),
        _fill(const Color(0xFFF3E9DC)));
    c.drawOval(
        Rect.fromCenter(
            center: Offset(e.x, e.y - 7 * s), width: 11 * s, height: 7 * s),
        _fill(const Color(0xFFE5484D)));
    c.drawCircle(Offset(e.x - 2 * s, e.y - 8 * s), 1 * s, _fill(Colors.white));
    c.drawCircle(Offset(e.x + 2 * s, e.y - 7 * s), 0.9 * s, _fill(Colors.white));
  }

  static void _hay(Canvas c, _El e, double p) {
    final s = e.s * p;
    c.drawOval(
        Rect.fromCenter(
            center: Offset(e.x, e.y - 6 * s), width: 24 * s, height: 16 * s),
        _fill(const Color(0xFFE5C158)));
    c.drawLine(Offset(e.x - 8 * s, e.y - 6 * s), Offset(e.x + 8 * s, e.y - 6 * s),
        _stroke(const Color(0x55A07A1E), 1.2 * s));
  }

  static void _fence(Canvas c, _El e, double p) {
    final s = e.s * p;
    final col = const Color(0xFFB98B5E);
    c.drawLine(Offset(e.x - 22 * s, e.y - 8 * s), Offset(e.x + 22 * s, e.y - 8 * s),
        _stroke(col, 1.6 * s));
    c.drawLine(Offset(e.x - 22 * s, e.y - 4 * s), Offset(e.x + 22 * s, e.y - 4 * s),
        _stroke(col, 1.6 * s));
    for (var i = -2; i <= 2; i++) {
      c.drawLine(Offset(e.x + i * 11 * s, e.y), Offset(e.x + i * 11 * s, e.y - 11 * s),
          _stroke(col, 2.4 * s));
    }
  }

  static void _lamp(Canvas c, _El e, double p, double t) {
    final s = e.s * p;
    c.drawLine(Offset(e.x, e.y), Offset(e.x, e.y - 22 * s),
        _stroke(const Color(0xFF4B5563), 2 * s));
    final glow = 0.55 + 0.25 * math.sin(t * 2 + e.a);
    c.drawCircle(Offset(e.x, e.y - 24 * s), 8 * s,
        _fill(Color.fromRGBO(255, 224, 130, 0.22 * glow)));
    c.drawCircle(
        Offset(e.x, e.y - 24 * s), 3 * s, _fill(const Color(0xFFFFE082)));
  }

  static void _windmill(Canvas c, _El e, double p, double t) {
    final s = e.s * p;
    _path
      ..reset()
      ..moveTo(e.x - 9 * s, e.y)
      ..lineTo(e.x - 5 * s, e.y - 40 * s)
      ..lineTo(e.x + 5 * s, e.y - 40 * s)
      ..lineTo(e.x + 9 * s, e.y)
      ..close();
    c.drawPath(_path, _fill(const Color(0xFFF1E4CF)));
    final hub = Offset(e.x, e.y - 42 * s);
    for (var i = 0; i < 4; i++) {
      final a = t * 0.8 + e.a + i * math.pi / 2;
      final tip = hub + Offset(math.cos(a), math.sin(a)) * 26 * s;
      c.drawLine(hub, tip, _stroke(const Color(0xFF8B6B4A), 2.2 * s));
      final a2 = a + 0.25;
      final tip2 = hub + Offset(math.cos(a2), math.sin(a2)) * 22 * s;
      c.drawLine(hub + Offset(math.cos(a), math.sin(a)) * 8 * s, tip2,
          _stroke(const Color(0xFFFFFFFF), 3 * s));
    }
    c.drawCircle(hub, 3 * s, _fill(const Color(0xFF6B4423)));
  }

  static void _house(Canvas c, _El e, double p, double t, _Plan pl) {
    final s = e.s * p;
    if (s < 0.03) return;
    final two = e.k == 21;
    final wall = pl.houseColors[e.v % pl.houseColors.length];
    final roof = pl.roofColors[(e.v ~/ 3) % pl.roofColors.length];
    final w = 34 * s, h = (two ? 38 : 24) * s;
    c.drawOval(
        Rect.fromCenter(
            center: Offset(e.x, e.y + 2 * s), width: 46 * s, height: 9 * s),
        _fill(const Color(0x25000000)));
    // دودکش و دود
    if (e.v % 3 == 0) {
      final cx = e.x + w * 0.28;
      c.drawRect(Rect.fromLTWH(cx - 2.5 * s, e.y - h - 17 * s, 5 * s, 12 * s),
          _fill(const Color(0xFF8D6E63)));
      if (p > 0.95) {
        for (var q = 0; q < 3; q++) {
          final ph = (t * 0.35 + q / 3 + e.a) % 1.0;
          c.drawCircle(
              Offset(cx + math.sin(ph * 6 + e.a) * 3, e.y - h - 18 * s - ph * 26 * s),
              (2 + ph * 4) * s,
              _fill(Color.fromRGBO(190, 190, 195, (1 - ph) * 0.35)));
        }
      }
    }
    c.drawRect(Rect.fromLTWH(e.x - w / 2, e.y - h, w, h), _fill(wall));
    _path
      ..reset()
      ..moveTo(e.x - w / 2 - 4 * s, e.y - h)
      ..lineTo(e.x, e.y - h - 17 * s)
      ..lineTo(e.x + w / 2 + 4 * s, e.y - h)
      ..close();
    c.drawPath(_path, _fill(roof));
    c.drawRect(Rect.fromLTWH(e.x - 4 * s, e.y - 12 * s, 8 * s, 12 * s),
        _fill(const Color(0xFF7B4B2A)));
    final win = _fill(const Color(0xFFBFE3F5));
    c.drawRect(Rect.fromLTWH(e.x - w / 2 + 4 * s, e.y - 19 * s, 7 * s, 7 * s), win);
    c.drawRect(Rect.fromLTWH(e.x + w / 2 - 11 * s, e.y - 19 * s, 7 * s, 7 * s),
        _fill(const Color(0xFFBFE3F5)));
    if (two) {
      c.drawRect(
          Rect.fromLTWH(e.x - w / 2 + 4 * s, e.y - 33 * s, 7 * s, 7 * s),
          _fill(const Color(0xFFFFE9A8)));
      c.drawRect(
          Rect.fromLTWH(e.x + w / 2 - 11 * s, e.y - 33 * s, 7 * s, 7 * s),
          _fill(const Color(0xFFBFE3F5)));
    }
  }

  static void _tower(Canvas c, _El e, double p, double t) {
    final s = e.s * p;
    if (s < 0.03) return;
    final w = 28 * s, h = (62 + (e.v % 4) * 14) * s;
    c.drawOval(
        Rect.fromCenter(
            center: Offset(e.x, e.y + 2 * s), width: 40 * s, height: 8 * s),
        _fill(const Color(0x25000000)));
    c.drawRect(Rect.fromLTWH(e.x - w / 2, e.y - h, w, h),
        _fill(const Color(0xFF8FA3B8)));
    c.drawRect(Rect.fromLTWH(e.x - w / 2 - 2 * s, e.y - h - 4 * s, w + 4 * s, 5 * s),
        _fill(const Color(0xFF64748B)));
    final rows = (h / (12 * s)).floor() - 1;
    for (var i = 0; i < rows; i++) {
      for (var j = 0; j < 3; j++) {
        final lit = ((i * 7 + j * 13 + e.v) % 3) == 0;
        c.drawRect(
            Rect.fromLTWH(e.x - w / 2 + (3 + j * 8) * s, e.y - h + (6 + i * 12) * s,
                5 * s, 6 * s),
            _fill(lit ? const Color(0xFFFFE9A8) : const Color(0xFF3B556E)));
      }
    }
  }

  static void _barn(Canvas c, _El e, double p) {
    final s = e.s * p;
    if (s < 0.03) return;
    final w = 40 * s, h = 26 * s;
    c.drawOval(
        Rect.fromCenter(
            center: Offset(e.x, e.y + 2 * s), width: 52 * s, height: 9 * s),
        _fill(const Color(0x25000000)));
    c.drawRect(Rect.fromLTWH(e.x - w / 2, e.y - h, w, h),
        _fill(const Color(0xFFC2453B)));
    _path
      ..reset()
      ..moveTo(e.x - w / 2 - 3 * s, e.y - h)
      ..lineTo(e.x - w * 0.3, e.y - h - 14 * s)
      ..lineTo(e.x + w * 0.3, e.y - h - 14 * s)
      ..lineTo(e.x + w / 2 + 3 * s, e.y - h)
      ..close();
    c.drawPath(_path, _fill(const Color(0xFF7F2A24)));
    c.drawRect(Rect.fromLTWH(e.x - 7 * s, e.y - 16 * s, 14 * s, 16 * s),
        _fill(const Color(0xFFF3E9DC)));
    final x = _stroke(const Color(0xFFC2453B), 1.4 * s);
    c.drawLine(Offset(e.x - 7 * s, e.y - 16 * s), Offset(e.x + 7 * s, e.y), x);
    c.drawLine(Offset(e.x + 7 * s, e.y - 16 * s), Offset(e.x - 7 * s, e.y), x);
  }

  static void _pond(Canvas c, _El e, double p, double t) {
    final s = e.s * p;
    final w = 90 * s, h = 52 * s;
    final r = Rect.fromCenter(center: Offset(e.x, e.y), width: w, height: h);
    c.drawOval(r.inflate(3 * s), _fill(const Color(0x338BC48A)));
    c.drawOval(r, _fill(const Color(0xFF6EC1E4)));
    c.drawOval(r.deflate(7 * s), _fill(const Color(0xFF8AD3F0)));
    final rp = (t * 0.25 + e.a) % 1.0;
    c.drawOval(
        Rect.fromCenter(
            center: Offset(e.x - 8 * s, e.y - 2 * s),
            width: w * 0.5 * rp,
            height: h * 0.4 * rp),
        _stroke(Color.fromRGBO(255, 255, 255, (1 - rp) * 0.55), 1.2));
  }

  static void _field(Canvas c, _El e, double p) {
    final s = e.s * p;
    c.save();
    c.translate(e.x, e.y);
    c.rotate((e.v % 7 - 3) * 0.08);
    final w = 130 * s, h = 80 * s;
    final golden = e.v % 2 == 0;
    c.drawRect(Rect.fromCenter(center: Offset.zero, width: w, height: h),
        _fill(golden ? const Color(0x55E5C158) : const Color(0x558CCB6B)));
    final pa = _stroke(
        golden ? const Color(0x88C9A227) : const Color(0x884C9A3A), 1.6);
    for (var i = -3; i <= 3; i++) {
      c.drawLine(Offset(-w / 2, i * h / 7), Offset(w / 2, i * h / 7), pa);
    }
    c.restore();
  }

  static void _rainbow(Canvas c, _El e, double p) {
    const cols = [
      Color(0xFFFF6B6B), Color(0xFFFFA94D), Color(0xFFFFE066),
      Color(0xFF69DB7C), Color(0xFF4DABF7), Color(0xFF9775FA),
    ];
    final ce = Offset(e.x, e.y);
    for (var i = 0; i < cols.length; i++) {
      final r = (190 - i * 9) * e.s * p;
      c.drawArc(
          Rect.fromCircle(center: ce, radius: r),
          math.pi,
          math.pi,
          false,
          _stroke(cols[i].withAlpha(90), 7 * e.s, cap: StrokeCap.butt));
    }
  }

  static void _balloon(Canvas c, _El e, double p, double t) {
    final s = e.s * p;
    final ce = Offset(e.x + math.sin(t * 0.15 + e.a) * 60,
        e.y - 110 - math.sin(t * 0.1 + e.a) * 18);
    c.drawOval(
        Rect.fromCenter(
            center: Offset(ce.dx, ce.dy + 70 * s), width: 30 * s, height: 8 * s),
        _fill(const Color(0x18000000)));
    c.drawOval(Rect.fromCenter(center: ce, width: 34 * s, height: 42 * s),
        _fill(const Color(0xFFE5484D)));
    c.drawOval(Rect.fromCenter(center: ce, width: 14 * s, height: 42 * s),
        _fill(const Color(0xFFFFD54F)));
    final pa = _stroke(const Color(0xFF6B4423), 1 * s);
    c.drawLine(ce + Offset(-8 * s, 20 * s), ce + Offset(-4 * s, 32 * s), pa);
    c.drawLine(ce + Offset(8 * s, 20 * s), ce + Offset(4 * s, 32 * s), pa);
    c.drawRect(Rect.fromLTWH(ce.dx - 5 * s, ce.dy + 32 * s, 10 * s, 7 * s),
        _fill(const Color(0xFF8B5A2B)));
  }

  static void _ufo(Canvas c, _El e, double p, double t) {
    final s = e.s * p;
    final ce = Offset(e.x + math.sin(t * 0.2 + e.a) * 120,
        e.y - 170 + math.sin(t * 0.7) * 6);
    _path
      ..reset()
      ..moveTo(ce.dx - 8 * s, ce.dy + 4 * s)
      ..lineTo(ce.dx - 26 * s, ce.dy + 70 * s)
      ..lineTo(ce.dx + 26 * s, ce.dy + 70 * s)
      ..lineTo(ce.dx + 8 * s, ce.dy + 4 * s)
      ..close();
    c.drawPath(_path, _fill(const Color(0x14B8F2FF)));
    c.drawOval(
        Rect.fromCenter(
            center: ce + Offset(0, -5 * s), width: 18 * s, height: 14 * s),
        _fill(const Color(0xAA9AE6FF)));
    c.drawOval(Rect.fromCenter(center: ce, width: 44 * s, height: 13 * s),
        _fill(const Color(0xFF94A3B8)));
    for (var i = -1; i <= 1; i++) {
      final on = ((t * 3).floor() + i) % 2 == 0;
      c.drawCircle(
          ce + Offset(i * 12 * s, 1 * s),
          1.7 * s,
          _fill(on ? const Color(0xFFFFE066) : const Color(0xFFE5484D)));
    }
  }

  static void _car(Canvas c, Offset pos, double ang, Color col) {
    c.save();
    c.translate(pos.dx, pos.dy);
    c.rotate(ang);
    c.drawRRect(
        RRect.fromRectAndRadius(
            const Rect.fromLTWH(-9, -4.5, 18, 9), const Radius.circular(2.5)),
        _fill(col));
    c.drawRRect(
        RRect.fromRectAndRadius(
            const Rect.fromLTWH(-3, -3.4, 7, 6.8), const Radius.circular(1.6)),
        _fill(const Color(0xBBDFF3FF)));
    c.drawCircle(const Offset(-5, -4.7), 1.7, _fill(const Color(0xFF1F2937)));
    c.drawCircle(const Offset(5, -4.7), 1.7, _fill(const Color(0xFF1F2937)));
    c.drawCircle(const Offset(-5, 4.7), 1.7, _fill(const Color(0xFF1F2937)));
    c.drawCircle(const Offset(5, 4.7), 1.7, _fill(const Color(0xFF1F2937)));
    c.drawCircle(const Offset(9, 0), 1.3, _fill(const Color(0xFFFFE9A8)));
    c.restore();
  }

  static void _birds(Canvas c, double m, double t, Rect vv) {
    final n = math.min(9, 3 + (m / 80).floor());
    final pa = _stroke(const Color(0xFF475569), 1.4);
    for (var j = 0; j < n; j++) {
      final x = -1100 + ((t * 28 + j * 70) % 2200);
      final y = -330 + 110 * math.sin(t * 0.3 + j) - j * 16;
      if (!vv.contains(Offset(x, y))) continue;
      final f = math.sin(t * 8 + j * 1.7) * 4;
      c.drawLine(Offset(x - 7, y - f), Offset(x, y), pa);
      c.drawLine(Offset(x, y), Offset(x + 7, y - f), pa);
    }
  }

  static void _clouds(Canvas c, double m, double t, bool dark, Rect vv) {
    final n = math.min(6, 2 + (m / 120).floor());
    final col = dark
        ? const Color.fromRGBO(255, 255, 255, 0.10)
        : const Color.fromRGBO(190, 208, 226, 0.32);
    for (var i = 0; i < n; i++) {
      final x = -2100 + ((i * 617 + t * (6 + i * 1.7)) % 4200);
      final y = -420 - i * 140.0;
      if (!vv.contains(Offset(x, y))) continue;
      c.drawCircle(Offset(x, y), 26, _fill(col));
      c.drawCircle(Offset(x + 26, y + 6), 20, _fill(col));
      c.drawCircle(Offset(x - 26, y + 7), 19, _fill(col));
      c.drawOval(Rect.fromCenter(center: Offset(x, y + 12), width: 92, height: 22),
          _fill(col));
    }
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  رشدِ برگ روی تنه / شاخه / زیرشاخه
//  هر چه کاربر وقتِ بیشتری روی یک شاخه بگذارد، برگ‌های بیشتری روی مسیرش
//  (از نوکِ شاخه تا تنه‌ی هدف) درمی‌آید؛ تازه‌ترین برگ آهسته بزرگ می‌شود.
// ═══════════════════════════════════════════════════════════════════════════
void drawTrunkGrowth(
  Canvas c,
  Offset Function(double) at,
  double Function(double) tangent,
  String id,
  double minutes,
  double t, {
  double scale = 1.0,
}) {
  final nf = math.min(26.0, 0.35 * math.pow(minutes, 0.6));
  if (nf < 0.05) return;
  final n = nf.floor();
  final frac = nf - n;
  final off = seeded('tg-$id')();
  final vv = WorldLayer.view.inflate(40);
  final count = frac > 0.01 ? n + 1 : n;
  for (var i = 0; i < count; i++) {
    final g = i < n ? 1.0 : frac;
    final u = ((off + (i + 1) * 0.6180339887) % 1.0) * 0.86 + 0.07;
    final p = at(u);
    if (WorldLayer.view != Rect.zero && !vv.contains(p)) continue;
    final side = i.isEven ? 1.0 : -1.0;
    final a = tangent(u) + math.pi + side * (0.75 + 0.3 * math.sin(i * 1.7)) +
        math.sin(t * 1.1 + i * 0.9) * 0.08;
    final len = (7 + 5 * ((i * 37) % 10) / 10) * scale * _ease(g);
    if (len < 0.5) continue;
    final gr = _kGreens[i % 4];
    final dir = Offset(math.cos(a), math.sin(a));
    final nrm = Offset(-dir.dy, dir.dx);
    final tip = p + dir * len;
    final mid = p + dir * (len * 0.5);
    _path
      ..reset()
      ..moveTo(p.dx, p.dy)
      ..quadraticBezierTo(mid.dx + nrm.dx * len * 0.38,
          mid.dy + nrm.dy * len * 0.38, tip.dx, tip.dy)
      ..quadraticBezierTo(mid.dx - nrm.dx * len * 0.38,
          mid.dy - nrm.dy * len * 0.38, p.dx, p.dy)
      ..close();
    c.drawPath(_path, _fill(i.isEven ? gr[0] : gr[1]));
  }
}
