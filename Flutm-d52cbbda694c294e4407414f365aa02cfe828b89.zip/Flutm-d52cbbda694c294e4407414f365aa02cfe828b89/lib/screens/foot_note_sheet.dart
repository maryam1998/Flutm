import 'package:flutter/material.dart';

import '../map/map_ops.dart';
import '../models/map_models.dart';
import '../services/note_fonts.dart';
import '../state/map_store.dart';
import '../theme/web_palette.dart';

const _kOk = Color(0xFF1E9E6A);
const _kGoldN = Color(0xFFC9962B);

const List<Color> _kNoteColors = [
  Color(0xFF000000),
  Color(0xFFFFFFFF),
  Color(0xFFD9534F),
  Color(0xFFE8408C),
  Color(0xFFF08A24),
  Color(0xFFE6B800),
  Color(0xFF1E9E6A),
  Color(0xFF1FA6A6),
  Color(0xFF2F6FED),
  Color(0xFF7A4BE0),
];

/// کادر ویرایشِ یادداشتِ کنار قدم (با تپ روی یادداشت روی نقشه باز می‌شود):
/// متن، فونت (دانلود با یک تپ)، اندازه، رنگ، برگشت به جای اول، حذف از نقشه.
/// «حذف از نقشه» فقط نمایشِ روی نقشه را خاموش می‌کند؛ متنِ یادداشت در تقویم می‌ماند.
Future<void> showFootNoteSheet(
  BuildContext context, {
  required MapStore store,
  required String hostId,
  required String actionId,
  required String jk,
}) {
  final host0 = store.state.findHost(hostId);
  if (host0 is! MapHost) return Future.value();
  final f0 = findActionNode(host0.actions, actionId);
  if (f0 == null) return Future.value();

  final wp = WebPalette.of(context);
  final node = f0.node;
  final ctl = TextEditingController(text: _noteText(node, jk));
  String? err;

  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    enableDrag: true,
    barrierColor: Colors.black.withValues(alpha: 0.15),
    backgroundColor: Colors.transparent,
    builder: (ctx) => Directionality(
      textDirection: TextDirection.rtl,
      child: StatefulBuilder(
        builder: (ctx, setS) {
          final st = footNoteStyle(node, jk);
          final curFont = (st['font'] as String?) ?? 'default';
          final size = ((st['size'] as num?)?.toDouble() ?? 1.0).clamp(0.4, 5.0);
          final colVal = st['color'] is int ? st['color'] as int : 0xFF000000;

          void save() {
            store.changed();
            setS(() {});
          }

          Future<void> pickFont(String id) async {
            if (id == 'default') {
              st.remove('font');
              err = null;
              save();
              return;
            }
            err = null;
            setS(() {});
            final ok = await NoteFonts.ensure(id);
            if (!ctx.mounted) return;
            if (ok) {
              st['font'] = id;
              err = null;
            } else {
              err = 'دانلود فونت انجام نشد؛ اینترنت را بررسی کن و دوباره بزن.';
            }
            save();
          }

          Widget fontTile(String id, String label) {
            final sel = curFont == id;
            final busy = id != 'default' && NoteFonts.isBusy(id);
            final ready = id == 'default' || NoteFonts.loaded.contains(id);
            return InkWell(
              borderRadius: BorderRadius.circular(12),
              onTap: busy ? null : () => pickFont(id),
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
                decoration: BoxDecoration(
                  color: sel ? _kOk.withValues(alpha: 0.12) : null,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                      color: sel ? _kOk : wp.textDim.withValues(alpha: 0.35),
                      width: sel ? 1.6 : 1),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      label,
                      style: TextStyle(
                        fontSize: 15,
                        color: wp.textMain,
                        fontFamily: id == 'default'
                            ? null
                            : NoteFonts.familyOf(id),
                        fontFamilyFallback: const ['Vazirmatn'],
                      ),
                    ),
                    const SizedBox(width: 8),
                    if (busy)
                      const SizedBox(
                          width: 14,
                          height: 14,
                          child: CircularProgressIndicator(strokeWidth: 2))
                    else
                      Icon(
                          sel
                              ? Icons.check_circle
                              : (ready
                                  ? Icons.check
                                  : Icons.download_rounded),
                          size: 16,
                          color: sel ? _kOk : wp.textDim),
                  ],
                ),
              ),
            );
          }

          Widget label(String t) => Text(t,
              style: TextStyle(
                  fontSize: 12.5,
                  fontWeight: FontWeight.w800,
                  color: wp.textMain));

          final keyboardOpen = MediaQuery.of(ctx).viewInsets.bottom > 0;

          return GestureDetector(
            behavior: HitTestBehavior.opaque,
            onVerticalDragEnd: (d) {
              if ((d.primaryVelocity ?? 0) > 250) Navigator.pop(ctx);
            },
            child: Container(
              constraints: BoxConstraints(
                  maxHeight: MediaQuery.of(ctx).size.height * 0.6),
              padding: EdgeInsets.fromLTRB(
                  16,
                  8,
                  16,
                  10 +
                      (keyboardOpen
                          ? MediaQuery.of(ctx).viewInsets.bottom
                          : MediaQuery.of(ctx).padding.bottom)),
              decoration: BoxDecoration(
                color: wp.panelBg,
                borderRadius:
                    const BorderRadius.vertical(top: Radius.circular(22)),
              ),
              child: SingleChildScrollView(
                physics: keyboardOpen
                    ? const ClampingScrollPhysics()
                    : const NeverScrollableScrollPhysics(),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Center(
                      child: Container(
                        width: 38,
                        height: 4,
                        margin: const EdgeInsets.only(bottom: 4),
                        decoration: BoxDecoration(
                          color: wp.textDim.withValues(alpha: 0.4),
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                    ),
                    Row(
                      children: [
                        Expanded(
                          child: Text('یادداشت روی نقشه',
                              style: TextStyle(
                                  fontSize: 15,
                                  fontWeight: FontWeight.w800,
                                  color: wp.textMain)),
                        ),
                        IconButton(
                          visualDensity: VisualDensity.compact,
                          onPressed: () => Navigator.pop(ctx),
                          icon: const Icon(Icons.check_rounded),
                          color: _kOk,
                          tooltip: 'تأیید',
                        ),
                      ],
                    ),
                    TextField(
                      controller: ctl,
                      minLines: 1,
                      maxLines: 2,
                      textDirection: TextDirection.rtl,
                      decoration: InputDecoration(
                        isDense: true,
                        hintText: 'متن یادداشت',
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12)),
                      ),
                      onChanged: (v) {
                        final m = _notes(node);
                        final t = v.trim();
                        if (t.isEmpty) {
                          m.remove(jk);
                          clearFootNoteState(node, jk);
                        } else {
                          m[jk] = t;
                        }
                        node.extra['footNotes'] = m;
                        store.changed();
                      },
                    ),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        Expanded(
                          child: _stateChip(
                            wp: wp,
                            icon: footNoteDone(node, jk)
                                ? Icons.check_circle_rounded
                                : Icons.radio_button_unchecked_rounded,
                            text: footNoteDone(node, jk)
                                ? 'انجام شد (خط خورد)'
                                : 'انجامش دادم',
                            color: _kOk,
                            on: footNoteDone(node, jk),
                            onTap: () {
                              if (_noteText(node, jk).isEmpty) return;
                              setFootNoteDone(
                                  node, jk, !footNoteDone(node, jk));
                              save();
                            },
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: _stateChip(
                            wp: wp,
                            icon: Icons.hourglass_bottom_rounded,
                            text: 'منتظر جواب',
                            color: _kGoldN,
                            on: footNoteWaiting(node, jk),
                            onTap: () {
                              if (_noteText(node, jk).isEmpty) return;
                              setFootNoteWaiting(
                                  node, jk, !footNoteWaiting(node, jk));
                              save();
                            },
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        label('فونت'),
                        const SizedBox(width: 10),
                        Expanded(
                          child: SizedBox(
                            height: 38,
                            child: ListView(
                              scrollDirection: Axis.horizontal,
                              children: [
                                fontTile('default', 'وزیرمتن (پیش‌فرض)'),
                                for (final nf in kNoteFonts) ...[
                                  const SizedBox(width: 8),
                                  fontTile(nf.id, nf.label),
                                ],
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                    if (err != null)
                      Padding(
                        padding: const EdgeInsets.only(top: 4),
                        child: Text(err!,
                            style: const TextStyle(
                                fontSize: 11.5, color: Color(0xFFD9534F))),
                      ),
                    const SizedBox(height: 2),
                    Row(
                      children: [
                        label('اندازه'),
                        Expanded(
                          child: SliderTheme(
                            data: SliderTheme.of(ctx).copyWith(
                                activeTrackColor: _kOk,
                                thumbColor: _kOk,
                                trackHeight: 3),
                            child: Slider(
                              min: 0.4,
                              max: 5.0,
                              value: size.toDouble(),
                              onChanged: (v) {
                                st['size'] = v;
                                save();
                              },
                            ),
                          ),
                        ),
                      ],
                    ),
                    Row(
                      children: [
                        label('رنگ'),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              for (final c in _kNoteColors)
                                GestureDetector(
                                  onTap: () {
                                    st['color'] = c.toARGB32();
                                    save();
                                  },
                                  child: Container(
                                    width: 26,
                                    height: 26,
                                    decoration: BoxDecoration(
                                      color: c,
                                      shape: BoxShape.circle,
                                      border: Border.all(
                                        color: colVal == c.toARGB32()
                                            ? _kGoldN
                                            : wp.textDim
                                                .withValues(alpha: 0.4),
                                        width:
                                            colVal == c.toARGB32() ? 3 : 1,
                                      ),
                                    ),
                                  ),
                                ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton.icon(
                            onPressed: () {
                              st.remove('dx');
                              st.remove('dy');
                              save();
                            },
                            icon: const Icon(Icons.undo_rounded, size: 18),
                            label: const Text('برگشت به جای اول',
                                style: TextStyle(fontSize: 12.5)),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: OutlinedButton.icon(
                            style: OutlinedButton.styleFrom(
                                foregroundColor: const Color(0xFFD9534F)),
                            onPressed: () {
                              st['hidden'] = true;
                              store.changed();
                              Navigator.pop(ctx);
                            },
                            icon: const Icon(Icons.visibility_off_outlined,
                                size: 18),
                            label: const Text('حذف از نقشه',
                                style: TextStyle(fontSize: 12.5)),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    ),
  ).whenComplete(ctl.dispose);
}

/// کنترل‌های سبکِ یادداشتِ روی نقشه (فونت، اندازه، رنگ، برگشت، حذف از نقشه)
/// به‌صورت ویجتِ جمع‌وجور برای قرار گرفتن داخلِ کادرِ آمار/تقویمِ قدم.
class FootNoteStyleControls extends StatefulWidget {
  const FootNoteStyleControls({
    super.key,
    required this.store,
    required this.node,
    required this.jk,
    this.onChanged,
  });

  final MapStore store;
  final ActionNode node;
  final String jk;
  final VoidCallback? onChanged;

  @override
  State<FootNoteStyleControls> createState() => _FootNoteStyleControlsState();
}

class _FootNoteStyleControlsState extends State<FootNoteStyleControls> {
  String? _err;

  void _save() {
    widget.store.changed();
    widget.onChanged?.call();
    if (mounted) setState(() {});
  }

  Future<void> _pickFont(Map<String, dynamic> st, String id) async {
    if (id == 'default') {
      st.remove('font');
      _err = null;
      _save();
      return;
    }
    setState(() => _err = null);
    final ok = await NoteFonts.ensure(id);
    if (!mounted) return;
    if (ok) {
      st['font'] = id;
      _err = null;
    } else {
      _err = 'دانلود فونت انجام نشد؛ اینترنت را بررسی کن و دوباره بزن.';
    }
    _save();
  }

  @override
  Widget build(BuildContext context) {
    final wp = WebPalette.of(context);
    final node = widget.node;
    final jk = widget.jk;
    final st = footNoteStyle(node, jk);
    final curFont = (st['font'] as String?) ?? 'default';
    final size = ((st['size'] as num?)?.toDouble() ?? 1.0).clamp(0.4, 5.0);
    final colVal = st['color'] is int ? st['color'] as int : 0xFF000000;

    Widget label(String t) => SizedBox(
          width: 44,
          child: Text(t,
              style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w800,
                  color: wp.textMain)),
        );

    Widget fontTile(String id, String text) {
      final sel = curFont == id;
      final busy = id != 'default' && NoteFonts.isBusy(id);
      final ready = id == 'default' || NoteFonts.loaded.contains(id);
      return InkWell(
        borderRadius: BorderRadius.circular(10),
        onTap: busy ? null : () => _pickFont(st, id),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
          decoration: BoxDecoration(
            color: sel ? _kOk.withValues(alpha: 0.12) : null,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(
                color: sel ? _kOk : wp.textDim.withValues(alpha: 0.35),
                width: sel ? 1.6 : 1),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                text,
                style: TextStyle(
                  fontSize: 13,
                  color: wp.textMain,
                  fontFamily: id == 'default' ? null : NoteFonts.familyOf(id),
                  fontFamilyFallback: const ['Vazirmatn'],
                ),
              ),
              const SizedBox(width: 6),
              if (busy)
                const SizedBox(
                    width: 12,
                    height: 12,
                    child: CircularProgressIndicator(strokeWidth: 2))
              else
                Icon(
                    sel
                        ? Icons.check_circle
                        : (ready ? Icons.check : Icons.download_rounded),
                    size: 14,
                    color: sel ? _kOk : wp.textDim),
            ],
          ),
        ),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      mainAxisSize: MainAxisSize.min,
      children: [
        Row(
          children: [
            label('فونت'),
            Expanded(
              child: SizedBox(
                height: 34,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  children: [
                    fontTile('default', 'وزیرمتن (پیش‌فرض)'),
                    for (final nf in kNoteFonts) ...[
                      const SizedBox(width: 6),
                      fontTile(nf.id, nf.label),
                    ],
                  ],
                ),
              ),
            ),
          ],
        ),
        if (_err != null)
          Padding(
            padding: const EdgeInsets.only(top: 4),
            child: Text(_err!,
                style:
                    const TextStyle(fontSize: 11, color: Color(0xFFD9534F))),
          ),
        Row(
          children: [
            label('اندازه'),
            Expanded(
              child: SliderTheme(
                data: SliderTheme.of(context).copyWith(
                    activeTrackColor: _kOk, thumbColor: _kOk, trackHeight: 3),
                child: Slider(
                  min: 0.4,
                  max: 5.0,
                  value: size.toDouble(),
                  onChanged: (v) {
                    st['size'] = v;
                    _save();
                  },
                ),
              ),
            ),
          ],
        ),
        Row(
          children: [
            label('رنگ'),
            Expanded(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  for (final c in _kNoteColors)
                    GestureDetector(
                      onTap: () {
                        st['color'] = c.toARGB32();
                        _save();
                      },
                      child: Container(
                        width: 22,
                        height: 22,
                        decoration: BoxDecoration(
                          color: c,
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: colVal == c.toARGB32()
                                ? _kGoldN
                                : wp.textDim.withValues(alpha: 0.4),
                            width: colVal == c.toARGB32() ? 3 : 1,
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ],
        ),
        const SizedBox(height: 6),
        Row(
          children: [
            Expanded(
              child: OutlinedButton.icon(
                style: OutlinedButton.styleFrom(
                    visualDensity: VisualDensity.compact),
                onPressed: () {
                  st.remove('dx');
                  st.remove('dy');
                  _save();
                },
                icon: const Icon(Icons.undo_rounded, size: 16),
                label: const Text('برگشت به جای اول',
                    style: TextStyle(fontSize: 12)),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: OutlinedButton.icon(
                style: OutlinedButton.styleFrom(
                    visualDensity: VisualDensity.compact,
                    foregroundColor: const Color(0xFFD9534F)),
                onPressed: () {
                  st['hidden'] = true;
                  _save();
                },
                icon: const Icon(Icons.visibility_off_outlined, size: 16),
                label: const Text('حذف از نقشه',
                    style: TextStyle(fontSize: 12)),
              ),
            ),
          ],
        ),
      ],
    );
  }
}

Map<String, dynamic> _notes(ActionNode n) {
  final v = n.extra['footNotes'];
  return v is Map ? Map<String, dynamic>.from(v) : <String, dynamic>{};
}

String _noteText(ActionNode n, String jk) => (_notes(n)[jk] as String?) ?? '';

/// دکمه‌ی گردِ وضعیتِ یادداشت (انجام شد / منتظر جواب)
Widget _stateChip({
  required WebPalette wp,
  required IconData icon,
  required String text,
  required Color color,
  required bool on,
  required VoidCallback onTap,
}) {
  return InkWell(
    borderRadius: BorderRadius.circular(12),
    onTap: onTap,
    child: AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 9),
      decoration: BoxDecoration(
        color: on ? color.withValues(alpha: 0.14) : null,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
            color: on ? color : wp.textDim.withValues(alpha: 0.35),
            width: on ? 1.6 : 1),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, size: 17, color: on ? color : wp.textDim),
          const SizedBox(width: 6),
          Flexible(
            child: Text(text,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                    fontSize: 12.5,
                    fontWeight: FontWeight.w700,
                    color: on ? color : wp.textMain)),
          ),
        ],
      ),
    ),
  );
}
